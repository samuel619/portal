import { cyan } from "ansi-colors"
import 'cypress-file-upload'

let LOCAL_STORAGE_MEMORY = {}

Cypress.Commands.add("saveLocalStorage", () => {
  Object.keys(localStorage).forEach(key => {
    LOCAL_STORAGE_MEMORY[key] = localStorage[key]
  })
})

Cypress.Commands.add("restoreLocalStorage", () => {
  Object.keys(LOCAL_STORAGE_MEMORY).forEach(key => {
    localStorage.setItem(key, LOCAL_STORAGE_MEMORY[key])
  })
})

Cypress.Commands.add("loadSchema", () => {
  cy.exec(`curl -u ${Cypress.env('fauna_auth_key')}: https://graphql.fauna.com/import --data-binary "@schema.gql"`)
})

Cypress.Commands.add("cleanup", () => {
  cy.exec(`fauna eval talenth-ci --file=./fauna/cleanup.fql --secret=${Cypress.env('FAUNADB_KEY')}`)
})

Cypress.Commands.add("seedRecruiter", () => {
  cy.exec(`fauna eval talenth-ci --file=./fauna/seed/recruiter.fql --secret=${Cypress.env('FAUNADB_KEY')}`)
})

Cypress.Commands.add("seedApplicant", () => {
  cy.exec(`fauna eval talenth-ci --file=./fauna/seed/applicant.fql --secret=${Cypress.env('FAUNADB_KEY')}`)
})