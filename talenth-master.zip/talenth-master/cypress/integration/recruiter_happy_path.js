describe('Recruiter', () => {
  beforeEach(function() {
    cy.restoreLocalStorage()
  })

  afterEach(function() {
    cy.saveLocalStorage()
  })

  it('can sign in', function() {
    cy.fixture('user.json').as('user')
    cy.visit('/')

    cy.get('.secondary-button').click()
    cy.url().should('include', '/signin')

    cy.get('@user').then(user => {
      cy.get('input[name="email"]').type(user.email)
      cy.get('input[name="password"]').type(user.password)
    })
    cy.contains('Sign in').click()
    cy.url().should('include', '/')
    cy.get('.initials').contains('TU')
  })

  it('can add a company', function() {
    cy.fixture('company.json').as('company')
    cy.fixture('stormtrooper.png', 'base64').as('logo')

    cy.contains('Company').click()
    cy.url().should('include', '/company')
    cy.contains('No company found, please add a company to start posting jobs!')
    cy.contains('Add Company').click()

    cy.url().should('include', '/add_company')

    cy.get('@company').then(company => {
      cy.get('input[name="name"]').type(company.name)
      cy.get('input[name="email"]').type(company.email)
      cy.get('textarea[name="about"]').type(company.about)
      cy.get('input[name="address"]').type(company.address)
    })

    cy.get('.autocomplete-dropdown-container').first().click()

    cy.get('@logo').then(logo => {
      cy.get('input[type=file]').upload({
        fileContent: logo,
        fileName: 'stormtrooper.png',
        mimeType: 'image/png'
      })
    })
    cy.wait(500)
    cy.get('[data-cy=submit]').click()

    cy.url().should('include', '/company')
    cy.get('.header img').should('have.attr', 'src').should('include', 'stormtrooper.png')
    cy.get('@company').then(company => {
      cy.contains(company.name)
      cy.contains(company.address)
      cy.contains(company.email)
    })
  })

  it('can edit a company', function() {
    cy.fixture('company.json').as('company')

    cy.get('[data-cy=edit]').click()
    cy.url().should('include', '/edit_company')

    cy.get('@company').then(company => {
      cy.get('input[name="name"]').invoke('val').should('contain', company.name)
      cy.get('input[name="name"]').clear().type("Updated Company")
      cy.get('textarea[name="about"]').invoke('val').should('contain', company.about)
      cy.get('textarea[name="about"]').clear().type("Updated")
      cy.get('input[name="address"]').invoke('val').should('contain', company.address)
      cy.get('input[name="email"]').invoke('val').should('contain', company.email)
      cy.get('input[name="email"]').clear().type("info@test.com")
    })

    cy.get('input[name="address"]').clear().type("San Francisco")
    cy.get('.autocomplete-dropdown-container').first().click()
    cy.get('[data-cy=submit]').click()

    cy.url().should('include', '/company')
    cy.get('.header img').should('have.attr', 'src').should('include', 'stormtrooper.png')
    cy.contains("Updated Company")
    cy.contains("San Francisco")
    cy.contains("info@test.com")
  })

  it('can post a job', function() {
    cy.fixture('job.json').as('job')

    cy.contains('Jobs').click()
    cy.url().should('include', '/my_jobs')
    cy.contains('No jobs found, please post jobs to start tracking!')
    cy.contains('Post Job').click()

    cy.url().should('include', '/post_job')

    cy.get('@job').then(job => {
      cy.get('input[name="title"]').type(job.title)
      cy.get('.single-select').click()
      cy.get('.select__menu').contains('Internal').click()
      cy.get('div[data-slate-editor="true"]').click().type(job.description)
      cy.get('[data-cy=submit]').click()

      cy.contains(job.title)
    })
  })

  it('can edit a job', function() {
    cy.fixture('job.json').as('job')

    cy.get('[data-cy=edit]').click()
    cy.url().should('include', '/edit_job')
    cy.contains("Update a job post")
    cy.get('@job').then(job => {
      cy.get('input[name="title"]').invoke('val').should('contain', job.title)
    })

    cy.get('input[name="title"]').clear().type("Full stack software engineer")
    cy.get('.single-select').click()
    cy.get('.select__menu').contains('Published').click()
    cy.get('[data-cy=submit]').click()
    cy.contains("Full stack software engineer")
  })

  it('can add a talent', function() {
    cy.fixture('talent.json').as('talent')
    cy.fixture('cv.pdf', 'base64').as('cv')

    cy.contains('Hiring pipeline').click()
    cy.url().should('include', '/talents')
    cy.contains('New Lead')
    cy.contains('Initial Screen')
    cy.contains('Phone Screen')
    cy.contains('On-site Interview')
    cy.contains('Reference Check')
    cy.contains('Offer')
    cy.contains('Hired')
    cy.contains('Add Talent').click()

    cy.url().should('include', '/add_talent')

    cy.get('@talent').then(talent => {
      cy.get('input[name="name"]').type(talent.name)
      cy.get('input[name="title"]').type(talent.title)
      cy.get('input[name="email"]').type(talent.email)
    })

    cy.get('@cv').then(cv => {
      cy.get('input[type=file]').upload({
        fileContent: cv,
        fileName: 'cv.pdf',
        mimeType: 'application/pdf'
      })
    })

    cy.get('.single-select').click()
    cy.get('.select__menu').contains("Full stack software engineer").click()
    cy.get('[data-cy=submit]').click()

    cy.url().should('include', '/talents')
  })

  it('can view and edit a talent', function() {
    cy.fixture('talent.json').as('talent')

    cy.get('@talent').then(talent => {
      cy.get('.table').should('contain', talent.name)
      cy.get('.table').should('contain', talent.title)
      cy.get('.table').contains(talent.name).click()
      cy.get('.header').contains(talent.name)
      cy.get('.header').contains(talent.title)
      cy.get('.left').contains('Full stack software engineer')
      cy.get('.right').contains('Active')
      cy.get('.right').contains('New Lead')
      cy.get('.right').contains(talent.email)
      cy.get('.right').contains('cv.pdf')
    })

    cy.get('.right .state').click()
    cy.get('.right .state .select__menu').contains('Archived').click()
    cy.get('.right .interview-stage').click()
    cy.get('.right .interview-stage .select__menu').contains('Hired').click()
    cy.get('textarea[name="note"]').type("test note")
    cy.get('[data-cy=add-note]').click()
    cy.wait(500)

    cy.contains('Hiring pipeline').click()
    cy.get('#Hired').click()
    cy.get('@talent').then(talent => {
      cy.get('.table').should('contain', talent.name)
    })
  })
})