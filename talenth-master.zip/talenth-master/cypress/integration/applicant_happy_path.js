describe('Applicant', () => {
  it('can see a searchbox', function() {
    cy.visit('/')

    cy.contains('Looking for a job?')
    cy.contains('Open Positions')
    cy.get('.info').contains(1)
  })

  it('can see jobs', function() {
    cy.contains('Jobs').click()
    cy.url().should('include', '/jobs')
    cy.get('.results').contains('1 results')

    cy.contains('Full stack software engineer')
    cy.contains('Awesome company')
    cy.contains('Yerevan, Armenia')
  })

  it('can see a job details', function() {
    cy.get('.item').click()

    cy.get('.description').contains('About Awesome company')
    cy.get('.description').contains('A test company')
    cy.get('.description').contains('Job Description')
    cy.get('.description').contains('Yet another job')
  })

  it('can apply to a job', function() {
    cy.fixture('applicant.json').as('applicant')
    cy.fixture('cv.pdf', 'base64').as('cv')

    cy.get('[data-cy=apply]').click()

    cy.contains('Full stack software engineer')
    cy.contains('Awesome company')
    cy.contains('Yerevan, Armenia')

    cy.get('@applicant').then(applicant => {
      cy.get('input[name="name"]').type(applicant.name)
      cy.get('input[name="email"]').type(applicant.email)
      cy.get('div[data-slate-editor="true"]').click().type(applicant.notes)
    })

    cy.get('@cv').then(cv => {
      cy.get('input[type=file]').upload({
        fileContent: cv,
        fileName: 'cv.pdf',
        mimeType: 'application/pdf'
      })
    })

    cy.get('[data-cy=submit]').click()
  })
})