echo "FAUNA: Loading schema..."
curl -u $FAUNADB_KEY: https://graphql.fauna.com/import --data-binary "@schema.gql"