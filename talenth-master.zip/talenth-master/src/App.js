import React, { PureComponent } from 'react'
import { Router, Route } from 'react-router-dom'
import { withApollo } from 'react-apollo'
import { createBrowserHistory } from 'history'

import { library } from '@fortawesome/fontawesome-svg-core'
import {
  faPlus,
  faUser,
  faHome,
  faBriefcase,
  faUserFriends,
  faChartPie,
  faFileImage,
  faCheck,
  faChevronLeft,
  faRocket,
  faBullhorn,
  faGraduationCap,
  faCode,
  faBicycle,
  faMotorcycle,
  faPlane,
  faSearch,
  faExclamation,
  faSignInAlt,
  faCloudUploadAlt,
  faExternalLinkSquareAlt,
  faTimesCircle,
  faEnvelope,
  faMapMarkedAlt,
  faFilter,
  faUserPlus,
  faPlug,
  faTasks,
  faAngleLeft,
  faAngleRight,
  faAngleDown,
  faSpinner,
  faSyncAlt,
  faPen,
  faShare,
  faEye
} from '@fortawesome/free-solid-svg-icons'
import { faLinkedinIn } from '@fortawesome/free-brands-svg-icons'

import './App.scss'

import PrivateRoute from './components/private_route'
import { VALIDATE_TOKEN } from './queries'

import Home from './pages/home'
import SignIn from './pages/sign_in'
import Company from './pages/company'
import AddCompany from './pages/add_company'
import EditCompany from './pages/edit_company'
import MyJobs from './pages/my_jobs'
import PostJob from './pages/post_job'
import EditJob from './pages/edit_job'
import Jobs from './pages/jobs'
import Apply from './pages/apply'
import Preview from './pages/preview'
import Talents from './pages/talents'
import AddTalent from './pages/add_talent'
import Talent from './pages/talent'
import Onboarding from './pages/onboarding'
import Checklists from './pages/checklists'
import AddChecklist from './pages/add_checklist'
import EditAction from './pages/edit_action'

import Header from './components/header'

library.add(
  faPlus,
  faUser,
  faHome,
  faBriefcase,
  faUserFriends,
  faChartPie,
  faFileImage,
  faCheck,
  faChevronLeft,
  faRocket,
  faBullhorn,
  faGraduationCap,
  faCode,
  faBicycle,
  faMotorcycle,
  faPlane,
  faSearch,
  faExclamation,
  faSignInAlt,
  faCloudUploadAlt,
  faExternalLinkSquareAlt,
  faTimesCircle,
  faLinkedinIn,
  faEnvelope,
  faMapMarkedAlt,
  faFilter,
  faUserPlus,
  faPlug,
  faTasks,
  faAngleLeft,
  faAngleRight,
  faAngleDown,
  faSpinner,
  faSyncAlt,
  faPen,
  faShare,
  faEye
)

const history = createBrowserHistory()

class App extends PureComponent {
  state = {
    user: null
  }

  async componentDidMount() {
    const response = await this.props.client.query({query: VALIDATE_TOKEN})
    this.setState({user: response.data.validateToken})
  }

  onSignUp(data) {
    localStorage.setItem('user', JSON.stringify(data))
    this.setState({user: data.user})
    history.push('/')
  }

  onSignIn(data) {
    localStorage.setItem('user', JSON.stringify(data))
    this.setState({user: data.user})
    history.push('/')
  }

  onSignOut() {
    localStorage.removeItem('user')
    history.push('/')
    this.setState({user: null})
  }

  render() {
    const {user} = this.state

    return (
      <Router history={history}>
        <Header user={user} onSignOut={() => this.onSignOut()} />

        <Route exact path="/" render={(props) => {
          return user ? 
          <MyJobs {...props} user={user} /> :
          <Home {...props} />
        }} />

        <Route exact path="/signin" render={props => <SignIn {...props} onSignIn={data => this.onSignIn(data)} />} />

        <Route path="/apply/:query?" component={Apply} />
        <Route path="/jobs/:query?" component={Jobs} />
        <Route path="/preview/:query?" component={Preview} />

        <PrivateRoute user={user} onSignIn={data => this.onSignIn(data)} path="/company" component={Company} />
        <PrivateRoute user={user} onSignIn={data => this.onSignIn(data)} path="/edit_company/:query?" component={EditCompany} />
        <PrivateRoute user={user} onSignIn={data => this.onSignIn(data)} path="/add_company" component={AddCompany} />
        <PrivateRoute user={user} onSignIn={data => this.onSignIn(data)} path="/my_jobs" component={MyJobs} />
        <PrivateRoute user={user} onSignIn={data => this.onSignIn(data)} path="/post_job" component={PostJob} />
        <PrivateRoute user={user} onSignIn={data => this.onSignIn(data)} path="/edit_job/:query?" component={EditJob} />
        <PrivateRoute user={user} onSignIn={data => this.onSignIn(data)} path="/talents/:query?" component={Talents} />
        <PrivateRoute user={user} onSignIn={data => this.onSignIn(data)} path="/talent/:query?" component={Talent} />
        <PrivateRoute user={user} onSignIn={data => this.onSignIn(data)} path="/add_talent" component={AddTalent} />
        <PrivateRoute user={user} onSignIn={data => this.onSignIn(data)} path="/onboarding" component={Onboarding} />
        <PrivateRoute user={user} onSignIn={data => this.onSignIn(data)} path="/checklists" component={Checklists} />
        <PrivateRoute user={user} onSignIn={data => this.onSignIn(data)} path="/add_checklist" component={AddChecklist} />
        <PrivateRoute user={user} onSignIn={data => this.onSignIn(data)} path="/edit_action/:query?" component={EditAction} />
      </Router>
    )
  }
}

export default withApollo(App)