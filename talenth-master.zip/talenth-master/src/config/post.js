export const OPTIONS = [
  {
    "icon": "bullhorn",
    "id": "promoted",
    "text": "Promoted",
    "price": "Contact us"
  },
  {
    "icon": "briefcase",
    "id": "regular",
    "text": "Regular",
    "price": "Free"
  },
  {
    "icon": "graduation-cap",
    "id": "internship",
    "text": "Internship",
    "price": "Free"
  },
  {
    "icon": "code",
    "id": "training",
    "text": "Training",
    "price": "Free"
  }
]
