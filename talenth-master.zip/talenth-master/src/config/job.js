export const INTERVIEW_STAGES = [
  {
    value: 'Initial Screen',
    label: 'Initial Screen'
  },
  {
    value: 'Phone Screen',
    label: 'Phone Screen'
  },
  {
    value: 'On-site Interview',
    label: 'On-site Interview'
  },
  {
    value: 'Reference Check',
    label: 'Reference Check'
  },
  {
    value: 'Offer',
    label: 'Offer'
  },
  {
    value: 'Hired',
    label: 'Hired'
  }
]

export const STATUSES = [
  {
    value: 'published',
    label: 'Published'
  },
  {
    value: 'internal',
    label: 'Internal'
  },
  {
    value: 'archived',
    label: 'Archived'
  }
]