import React, { PureComponent } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { withApollo } from 'react-apollo'
import { CREATE_JOB, FIND_COMPANY } from '../queries'

import InputWithLabel from '../components/base/input_with_label'
import TextEditor from '../components/base/text_editor'
import SelectWithLabel from '../components/base/select_with_label'

import { INTERVIEW_STAGES, STATUSES } from '../config/job'

class PostJob extends PureComponent {
  state = {
    isValid: true,
    job: {
      title: '',
      description: '',
      stages: INTERVIEW_STAGES,
      status: ''
    }
  }

  onChange(e) {
    const { name, value } = e.target

    this.setState(prevState => ({
      job: {
        ...prevState.job,
        [name]: value,
      },
    }))
  }

  onStageChange(selectedOption) {
    this.setState(prevState => ({
      job: {
        ...prevState.job,
        stages: selectedOption,
      }
    }))
  }

  onStatusChange(selectedOption) {
    this.setState(prevState => ({
      job: {
        ...prevState.job,
        status: selectedOption.value,
      }
    }))
  }

  onEditorChange(data) {
    this.setState(prevState => ({
      job: {
        ...prevState.job,
        description: data,
      }
    }))
  }

  async onSubmit() {
    const { client, history } = this.props 
    const { job } = this.state

    if (this.isValid()) {
      await client.mutate({
        mutation: CREATE_JOB,
        variables: {
          job: {
            title: job.title,
            status: job.status,
            stages: JSON.stringify(job.stages),
            description: JSON.stringify(job.description)
          }
        },
        update: (cache, { data: { createJob } }) => {
          const { findCompany } = cache.readQuery({ query: FIND_COMPANY })
          findCompany.jobs.data.push(createJob)
          cache.writeQuery({
            query: FIND_COMPANY,
            data: { findCompany }
          })
        }
      })
      history.push('/my_jobs')
    } else {
      this.setState({isValid: this.isValid()})
      window.scrollTo(0, 0)
    }
  }

  isValid() {
    const { job } = this.state
    return job.title !== '' && job.description !== ''
  }

  render() {
    const { job, isValid } = this.state

    return (
      <div className="container">
        <div className="header is-left">
          <h1>Create a job post</h1>
          <p>
            Please fill the form according to your needs.
            Fields marked with "*" are required, make sure to fill them out.
          </p>
        </div>
        <hr />
        <div className="body">
          <h3>Job details</h3>
          <div className="cols">
            <div className="left">
              <InputWithLabel 
                name="title"
                valid={isValid || job.title !== ''}
                label="Job title*"
                value={job.title}
                onChange={event => this.onChange(event)}
              />
            </div>
            <div className="right">
              <SelectWithLabel
                valid={true}
                isCreatable={false}
                isMulti={false}
                label="Job status"
                value={{
                  value: job.status,
                  label: job.status
                }}
                options={STATUSES}
                className="single-select"
                onChange={selectedOption => this.onStatusChange(selectedOption)}
              />
            </div>
          </div>
          <TextEditor
            name="description"
            valid={isValid || job.description !== ''}
            label="Job description*"
            onChange={data => this.onEditorChange(data)}
          />
        </div>
        <hr />
        <div className="body">
          <h3>Interview process</h3>
          <SelectWithLabel
            valid={true}
            isCreatable={true}
            isMulti={true}
            label="Interview stages*"
            value={job.stages}
            options={INTERVIEW_STAGES}
            className="multi-select"
            onChange={selectedOption => this.onStageChange(selectedOption)}
          />
        </div>
        <div className="action">
          <button className="button" data-cy="submit" onClick={() => this.onSubmit()}>
            <FontAwesomeIcon icon="rocket"/>
            Submit
          </button>
        </div>
      </div>
    )
  }
}

export default withApollo(PostJob)