import React, { PureComponent } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { withApollo } from 'react-apollo'
import { Helmet } from 'react-helmet'
import { BounceLoader } from 'react-spinners'
import Html from 'slate-html-serializer'

import { FIND_JOB, CREATE_APPLICATION } from '../queries'
import { RULES } from '../components/base/text_editor_config'

import Card from '../components/talent/card'
import InputWithLabel from '../components/base/input_with_label'
import TextEditor from '../components/base/text_editor'
import FileUpload from '../components/base/file_upload'

const HTML = new Html({ rules: RULES })

class Apply extends PureComponent {
  state = {
    job: null,
    isValid: true,
    loading: false,
    application: {
      name: '',
      email: '',
      notes: '',
      resume: ''
    }
  }

  async componentDidMount() {
    const { match, client } = this.props
    const response = await client.query({query: FIND_JOB, variables: {id: match.params.query}})

    this.setState({
      job: response.data.findJobByID
    })
  }

  isValid() {
    const { application } = this.state
    return application.name !== '' &&
      application.email !== ''
  }

  onChange(e) {
    const { name, value } = e.target

    this.setState(prevState => ({
      application: {
        ...prevState.application,
        [name]: value,
      }
    }))
  }

  onEditorChange(data) {
    this.setState(prevState => ({
      application: {
        ...prevState.application,
        notes: data,
      }
    }))
  }

  onFileUpload(file) {
    this.setState(prevState => ({
      application: {
        ...prevState.application,
        resume: JSON.stringify(file)
      }
    }))
  }

  onJobClick(job) {
    window.open(`/apply/${job._id}`, '_blank')
  }

  async onSubmit() {
    const { match, client, history } = this.props
    const { application } = this.state

    if (this.isValid()) {
      this.setState({loading: true})

      await client.mutate({
        mutation: CREATE_APPLICATION,
        variables: {
          application: {
            ...application,
            notes: JSON.stringify(application.notes),
            job: {
              connect: match.params.query
            }
          }
        }
      })
      history.push('/jobs')
    } else {
      this.setState({isValid: this.isValid()})
      window.scrollTo(0, 0)
    }
  }

  render() {
    const { match } = this.props
    const { job, application, isValid, loading } = this.state

    if (!job) return (
      <BounceLoader
        sizeUnit={"px"}
        size={30}
        className="bounce"
      />
    )

    return (
      <div className="container">
        <Helmet>
          <title>{job.company.name}: {job.title} - Talenth</title>
          <meta name="description" content={`${job.company.name} is hiring through Talenth. View job listings and company information, and apply.`} />
          <meta property="og:title" content={`${job.company.name}: ${job.title} - Talenth`} />
          <meta property="og:description" content={`${job.company.name} is hiring through Talenth. View job listings and company information, and apply.`} />
          <meta property="og:url" content={`https://app.talenth.co/apply/${match.params.query}`} />
          <meta property="og:image" content={job.company.logo}/>
          <meta property="og:image:secure_url" content={job.company.logo}/>
          <link href={`https://app.talenth.co/apply/${match.params.query}`} rel='canonical' />
        </Helmet>
        <div className="header">
          <img src={job.company.logo} alt="company logo"/>
          <h1>{job.title}</h1>
          <p>{job.company.name} - {job.company.address}</p>
        </div>
        <hr />
        <div className="body">
          <div dangerouslySetInnerHTML={{__html: HTML.serialize(JSON.parse(job.description))}} />
        </div>
        <hr />
        <div className="body">
          <h3>Submit your application</h3>
          <div className="cols">
            <div className="left">
              <InputWithLabel
                name="name"
                valid={isValid || application.name !== ''}
                label="Full name*"
                value={application.name}
                onChange={event => {this.onChange(event)}}
              />
              <InputWithLabel
                name="email"
                valid={isValid || application.email !== ''}
                label="Email*"
                value={application.email}
                onChange={event => {this.onChange(event)}}
              />
            </div>
            <div className="right">
              <FileUpload
                name="resume"
                label="Resume (only .pdf)"
                accept="application/pdf"
                onFileUpload={file => this.onFileUpload(file)}
              />
            </div>
          </div>
          <TextEditor
            name="notes"
            valid={true}
            label="Additional information"
            onChange={data => this.onEditorChange(data)}
          />
        </div>
        <div className="action">
          <button className="button" data-cy="submit" onClick={() => this.onSubmit()}>
            { loading ? <FontAwesomeIcon icon="spinner" spin /> : <FontAwesomeIcon icon="rocket"/> }
            Submit
          </button>
        </div>
        <hr />
        <div className="body">
          <h3>Other jobs at {job.company.name}</h3>
          {
            job.company && job.company.jobs.data.map(j => (
              <Card key={j._id} job={j} company={job.company} onClick={j => this.onJobClick(j)}/>
            ))
          }
        </div>
      </div>
    )
  }
}

export default withApollo(Apply)
