import React, { PureComponent } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { withApollo } from 'react-apollo'

import { FIND_ACTION, UPDATE_ACTION } from '../queries'

import InputWithLabel from '../components/base/input_with_label'
import TextEditor from '../components/base/text_editor'
import { INITIAL_VALUE } from '../components/base/text_editor_config'

class EditAction extends PureComponent {
  state = {
    isValid: true,
    action: {
      name: '',
      assignee: '',
      content: ''
    }
  }

  async componentDidMount() {
    const { match, client } = this.props
    const { data } = await client.query({query: FIND_ACTION, variables: {id: match.params.query}})

    let content = INITIAL_VALUE
    //TEMP code should go away
    try {
      content = JSON.parse(data.findActionByID.content)
    } catch { }

    this.setState({
      action: {
        name: data.findActionByID.name,
        assignee: data.findActionByID.assignee,
        content
      }
    })
  }

  isValid() {
    const { action } = this.state
    return action.name !== ''
  }

  onChange(e) {
    const { name, value } = e.target

    this.setState(prevState => ({
      action: {
        ...prevState.action,
        [name]: value
      }
    }))
  }

  onEditorChange(data) {
    this.setState(prevState => ({
      action: {
        ...prevState.action,
        content: data
      }
    }))
  }

  async onSubmit() {
    const { match, client } = this.props
    const { action } = this.state

    if (this.isValid()) {
      await client.mutate({
        mutation: UPDATE_ACTION,
        variables: {
          id: match.params.query,
          action: {
            name: action.name,
            assignee: action.assignee,
            content: JSON.stringify(action.content)
          }
        }
      })
      this.props.history.push('/onboarding')
    } else {
      this.setState({isValid: this.isValid()})
      window.scrollTo(0, 0)
    }
  }

  render() {
    const { action, isValid } = this.state

    return (
      <div className="center-container">
        <div className="header">
          <h1>Edit an action</h1>
          <p>
            Please fill the form according to your needs.
            Fields marked with "*" are required, make sure to fill them out.
          </p>
        </div>
        <hr />
        <div className="section">
          <h1>General info</h1>
          <InputWithLabel
            name="name"
            label="Name*"
            value={action.name}
            valid={isValid || action.name !== ''}
            onChange={event => this.onChange(event)}
          />
          <InputWithLabel
            name="assignee"
            label="Assignee"
            value={action.assignee}
            valid={true}
            onChange={event => this.onChange(event)}
          />
          <TextEditor
            name="content"
            value={action.content}
            valid={true}
            label="Content"
            onChange={data => this.onEditorChange(data)}
          />
        </div>
        <div className="action">
          <button className="button" onClick={() => this.onSubmit()}>
            <FontAwesomeIcon icon="rocket"/>
            Submit
          </button>
        </div>
      </div>
    )
  }
}

export default withApollo(EditAction)
