import React, { PureComponent } from 'react'
import { withApollo } from 'react-apollo'
import { Helmet } from 'react-helmet'
import { BounceLoader } from 'react-spinners'
import Html from 'slate-html-serializer'
import { FIND_JOB } from '../queries'
import { RULES } from '../components/base/text_editor_config'

import '../styles/apply.scss'

const HTML = new Html({ rules: RULES })

class Preview extends PureComponent {
  state = {
    job: null,
    completed: false,
    isValid: true,
    profile: '',
    email: '',
    notes: ''
  }

  async componentDidMount() {
    const response = await this.props.client.query({query: FIND_JOB, variables: {id: this.props.match.params.query}})
    const data = response.data.findJobByID
    this.setState({
      job: data
    })
  }

  render() {
    const { job } = this.state

    if (!job) return (
      <BounceLoader
        sizeUnit={"px"}
        size={30}
        className="bounce"
      />
    )

    return (
      <div className="apply">
        <Helmet>
          <title>{job.company.name}: {job.title} - Talenth</title>
          <meta name="description" content={`${job.company.name} is hiring through Talenth. View job listings and company information, and apply.`} />
          <meta property="og:title" content={`${job.company.name}: ${job.title} - Talenth`} />
          <meta property="og:description" content={`${job.company.name} is hiring through Talenth. View job listings and company information, and apply.`} />
          <meta property="og:url" content={`https://app.talenth.co/preview/${this.props.match.params.query}`} />
          <meta property="og:image" content={job.company.logo}/>
          <meta property="og:image:secure_url" content={job.company.logo}/>
          <link href={`https://app.talenth.co/preview/${this.props.match.params.query}`} rel='canonical' />
        </Helmet>
        <div className="header">
          <img src={job.company.logo} alt="company logo"/>
          <h1>{job.title}</h1>
          <p>{job.company.address}</p>
        </div>
        <hr />
        <div className="body">
          <div dangerouslySetInnerHTML={{__html: HTML.serialize(JSON.parse(job.description))}} />
        </div>
      </div>
    )
  }
}

export default withApollo(Preview)
