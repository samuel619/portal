import React, { PureComponent, Fragment } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import PlacesAutocomplete, { geocodeByAddress, getLatLng } from 'react-places-autocomplete'
import { withApollo } from 'react-apollo'
import { CREATE_COMPANY, FIND_COMPANY } from '../queries'

import Map from '../components/map'
import InputWithLabel from '../components/base/input_with_label'
import TextWithLabel from '../components/base/text_with_label'
import FileUpload from '../components/base/file_upload'

import '../styles/container.scss'
import '../styles/base/input.scss'

class AddCompany extends PureComponent {
  state = {
    isValid: true,
    loading: false,
    company: {
      name: '',
      about: '',
      logo: '',
      address: '',
      latitude: '',
      longitude: '',
      email: ''
    }
  }

  onAddressChange(address) {
    this.setState(prevState => ({
      company: {
        ...prevState.company,
        address
      }
    }))
  }

  async onAddressSelect(address) {
    const results = await geocodeByAddress(address)
    const latLng = await getLatLng(results[0])

    this.setState(prevState => ({
      company: {
        ...prevState.company,
        address,
        latitude: latLng.lat,
        longitude: latLng.lng
      }
    }))
  }

  onChange(e) {
    const { name, value } = e.target

    this.setState(prevState => ({
      company: {
        ...prevState.company,
        [name]: value,
      }
    }))
  }

  onFileUpload(file) {
    this.setState(prevState => ({
      company: {
        ...prevState.company,
        logo: JSON.stringify(file)
      }
    }))
  }

  async onSubmit() {
    const { client, history } = this.props
    const { company } = this.state

    if (this.isValid()) {
      this.setState({loading: true})

      await client.mutate({
        mutation: CREATE_COMPANY,
        variables: { company },
        update: (cache, { data: { createCompany } }) => {
          cache.writeQuery({
            query: FIND_COMPANY,
            data: { findCompany: createCompany }
          })
        }
      })

      history.push('/company')
    } else {
      this.setState({isValid: this.isValid()})
      window.scrollTo(0, 0)
    }
  }

  isValid() {
    const { company } = this.state
    return company.name !== '' &&
      company.about !== '' &&
      company.logo !== '' &&
      company.address !== '' &&
      company.latitude !== '' &&
      company.longitude !== '' &&
      company.email !== ''
  }

  render() {
    const { company, loading, isValid } = this.state

    const isAddressValid = isValid || company.address !== ''

    return (
      <div className="container">
        <div className="header is-left">
          <h1>Company details</h1>
          <p>
            Please fill the form according to your needs.
            Fields marked with "*" are required, make sure to fill them out.
          </p>
        </div>
        <hr />
        <div className="body">
          <h3>General info</h3>
          <div className="cols">
            <div className="left">
              <InputWithLabel
                name="name"
                valid={isValid || company.name !== ''}
                label="Company name*"
                value={company.name}
                onChange={event => this.onChange(event)}
              />
              <InputWithLabel
                name="email"
                valid={isValid || company.email !== ''}
                label="Company email*"
                value={company.email}
                onChange={event => this.onChange(event)}
              />
            </div>
            <div className="right">
              <FileUpload
                name="logo"
                label="Logo (only image)"
                accept="image/*"
                onFileUpload={file => this.onFileUpload(file)}
              />
            </div>
          </div>
          <TextWithLabel
            name="about"
            valid={isValid || company.about !== ''}
            label="Company introduction*"
            value={company.about}
            onChange={event => this.onChange(event)}
          />
        </div>
        <div className="body map">
          <Map currentPost={company}/>
          <div className="input-group">
            <label>
              Company address*
              {!isAddressValid && <span className={isAddressValid ? '' : 'error'}>This field is required!</span>}
            </label>
            <PlacesAutocomplete
              options={{types: ['address']}}
              value={company.address || ''}
              onChange={address => this.onAddressChange(address)}
              onSelect={address => this.onAddressSelect(address)}
            >
              {({ getInputProps, suggestions, getSuggestionItemProps, loading }) => (
                <Fragment>
                  <input
                    {...getInputProps({
                      className: isAddressValid ? 'location-search-input' : 'location-search-input error',
                      name: 'address'
                    })}
                  />
                  {suggestions.length !== 0 && <div className="autocomplete-dropdown-container">
                    {loading && <div>Loading...</div>}
                    {suggestions.map(suggestion => {
                      const className = 'suggestion'
                      const style = suggestion.active
                        ? { backgroundColor: '#fafafa', cursor: 'pointer' }
                        : { backgroundColor: '#ffffff', cursor: 'pointer' }
                      return (
                        <div
                          {...getSuggestionItemProps(suggestion, {
                            className,
                            style,
                          })}
                        >
                          <span>{suggestion.description}</span>
                        </div>
                      );
                    })}
                  </div>}
                </Fragment>
              )}
            </PlacesAutocomplete>
          </div>
        </div>
        <div className="action">
          <button className="button" data-cy="submit" onClick={() => this.onSubmit()}>
            { loading ? <FontAwesomeIcon icon="spinner" spin /> : <FontAwesomeIcon icon="rocket"/> }
            Submit
          </button>
        </div>
      </div>
    )
  }
}

export default withApollo(AddCompany)