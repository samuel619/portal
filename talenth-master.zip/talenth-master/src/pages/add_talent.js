import React, { PureComponent } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { withApollo } from 'react-apollo'
import { withRouter } from 'react-router-dom'

import { FIND_COMPANY, ADD_TALENT } from '../queries'
import InputWithLabel from '../components/base/input_with_label'
import SelectWithLabel from '../components/base/select_with_label'
import FileUpload from '../components/base/file_upload'

import '../styles/add_talent.scss'
import '../styles/base/input.scss'

class AddTalent extends PureComponent {
  state = {
    isValid: true,
    loading: false,
    options: [],
    name: '',
    title: '',
    email: '',
    resume: null,
    stage: 'New Lead',
    state: 'Active',
    job: ''
  }

  async componentDidMount() {
    const response = await this.props.client.query({query: FIND_COMPANY})
    const company = response.data.findCompany

    const options = company.jobs.data.map(job => {
      return {
        value: job._id,
        label: job.title
      }
    })

    this.setState({options})
  }

  onChange(e) {
    this.setState({[e.target.name]: e.target.value})
  }

  onJobChange(selectedJob) {
    this.setState({job: selectedJob})
  }

  onFileUpload(file) {
    this.setState({resume: JSON.stringify(file)})
  }

  async onSubmit() {
    const { client, history } = this.props
    const { name, title, email, stage, state, resume, job } = this.state

    if (this.isValid()) {
      this.setState({loading: true})

      await client.mutate({
        mutation: ADD_TALENT,
        variables: {
          talent: { name, title, email, stage, resume, state,
            job: { connect: job.value }
          }
        },
        update: (cache, { data: { addTalent } }) => {
          const { findCompany } = cache.readQuery({ query: FIND_COMPANY })
          const jobIndex = findCompany.jobs.data.findIndex(job => job._id === this.state.job.value)

          if (findCompany.jobs.data[jobIndex].talents) {
            findCompany.jobs.data[jobIndex].talents.data.push(addTalent)  
          } else {
            findCompany.jobs.data[jobIndex].talents = {
              data: [ addTalent ]
            }
          }

          cache.writeQuery({
            query: FIND_COMPANY,
            data: { findCompany }
          })
        }
      })
      history.push('/talents')
    } else {
      this.setState({isValid: this.isValid()})
      window.scrollTo(0, 0)
    }
  }

  isValid() {
    const {name, email} = this.state
    return name !== '' &&
    email !== ''
  }

  render() {
    const { options, name, title, email, job, isValid, loading } = this.state

    return (
      <div className="container">
        <div className="header is-left">
          <h1>Add a talent</h1>
          <p>
            Please fill the form according to your needs.
            Fields marked with "*" are required, make sure to fill them out.
          </p>
        </div>
        <hr />
        <div className="body">
          <h3>General info</h3>
          <div className="cols">
            <div className="left">
              <InputWithLabel 
                name="name"
                label="Full name*"
                value={name}
                valid={isValid || name !== ''}
                onChange={event => this.onChange(event)}
              />
              <InputWithLabel 
                name="title"
                label="Title*"
                value={title}
                valid={isValid || title !== ''}
                onChange={event => this.onChange(event)}
              />
            </div>
            <div className="right">
              <FileUpload
                name="resume"
                label="Resume (only .pdf)"
                onFileUpload={file => this.onFileUpload(file)}
              />
            </div>
          </div>
          <InputWithLabel
            name="email"
            label="Email*"
            value={email}
            valid={isValid || email !== ''}
            onChange={event => this.onChange(event)}
          />
        </div>
        <hr />
        <div className="body job-select">
          <h3>Job details</h3>
          <SelectWithLabel
            isMulti={false}
            valid={isValid || job !== ''}
            label="Select job*"
            value={job}
            options={options}
            className="single-select"
            onChange={selectedOption => this.onJobChange(selectedOption)}
          />
        </div>
        <div className="action">
          <button className="button" data-cy="submit" onClick={() => this.onSubmit()}>
            { loading ? <FontAwesomeIcon icon="spinner" spin /> : <FontAwesomeIcon icon="rocket"/> }
            Submit
          </button>
        </div>
      </div>
    );
  }
}

export default withRouter(withApollo(AddTalent))
