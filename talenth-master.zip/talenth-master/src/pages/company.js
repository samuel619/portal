import React, { PureComponent } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { BounceLoader } from 'react-spinners'
import { withApollo } from 'react-apollo'
import { FIND_COMPANY } from '../queries'

import Map from '../components/map'

import '../styles/container.scss'

class Company extends PureComponent {
  state = {
    loading: true,
    company: null
  }

  async componentDidMount() {
    const response = await this.props.client.query({query: FIND_COMPANY})

    this.setState({
      company: response.data.findCompany,
      loading: false
    })
  }

  render() {
    const { loading, company } = this.state

    if (loading) return (
      <BounceLoader
        sizeUnit={"px"}
        size={30}
        className="bounce"
      />
    )

    if (!company) {
      return (
        <div className="container">
          <div className="is-hero">
            <div className="message">
              <h1>
                No company found, please add a company to start posting jobs!
                <span role="img" aria-label="wave">🏢</span>
              </h1>
            </div>
            <div className="action">
              <button className="button" onClick={() => this.props.history.push('/add_company')}>
                <FontAwesomeIcon icon="plus"/>
                Add Company
              </button>
            </div>
          </div>
        </div>
      )
    }

    return (
      <div className="container">
        <div className="header">
          <img src={company.logo} alt="company logo"/>
          <h1>{company.name}</h1>
          <p>{company.address}, {company.email}</p>
        </div>
        <hr />
        <div className="body">
          <h3>Map</h3>
          <Map currentPost={company}/>
        </div>
        <div className="action">
          <button className="button" data-cy="edit" onClick={() => this.props.history.push(`/edit_company/${company._id}`)}>
            <FontAwesomeIcon icon="pen"/>
            Edit
          </button>
        </div>
      </div>
    )
  }
}

export default withApollo(Company)