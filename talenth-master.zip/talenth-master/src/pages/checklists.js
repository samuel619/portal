import React, { Component } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { withApollo } from 'react-apollo'

import ListItem from '../components/list_item'
import Checklist from '../components/checklist'
import { ALL_CHECKLISTS } from '../queries'

class Checklists extends Component {
  state = {
    currentChecklist: null,
    checklists: [],
    filteredChecklists: [],
    query: ''
  }

  async componentDidMount() {
    const { data } = await this.props.client.query({query: ALL_CHECKLISTS})

    this.setState({
      checklists: data.allChecklists.data,
      currentChecklist: data.allChecklists.data[0],
      filteredChecklists: data.allChecklists.data.filter(checklist => checklist.name.toLowerCase().includes(this.state.query))
    })
  }

  onItemClick(item) {
    this.setState({currentChecklist: item})
  }

  onChange(e) {
    let filteredChecklists = this.state.checklists
    filteredChecklists = filteredChecklists.filter(checklist => checklist.name.toLowerCase().includes(e.target.value))
    this.setState({filteredChecklists, query: e.target.value})
  }

  render() {
    const { query, filteredChecklists, currentChecklist } = this.state

    return (
      <div className="container">
        <div className="aside">
          <div className="search">
            <input
              type="text"
              placeholder="Search for a checklist"
              value={query}
              onChange={event => this.onChange(event)}
            />
            <FontAwesomeIcon icon="search" />
            <div className="results">
              {filteredChecklists.length} results
            </div>
          </div>
          <div className="list">
            <h3>My checklists</h3>
            { filteredChecklists.map(checklist => (
              <ListItem key={checklist._id} data={checklist} onClick={checklist => this.onItemClick(checklist)} />
            ))}
          </div>
        </div>
        <Checklist template={currentChecklist} completable={false}/>
      </div>
    );
  }
}

export default withApollo(Checklists)