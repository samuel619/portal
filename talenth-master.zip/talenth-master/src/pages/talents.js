import React, { Component } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { withApollo } from 'react-apollo'
import groupBy from 'lodash.groupby'
import { BounceLoader } from 'react-spinners'

import Card from '../components/talent/card'
import TalentItem from '../components/talent/talent_item'

import { FIND_COMPANY } from '../queries'

const INITIAL_STAGE = {
  value: 'New Lead',
  label: 'New Lead'
}

class Talents extends Component {
  state = {
    currentJob: {},
    stage: 'New Lead',
    jobs: [],
    filteredJobs: null,
    query: ''
  }

  async componentDidMount() {
    const { data } = await this.props.client.query({query: FIND_COMPANY})
    const company = data.findCompany
    const jobs = company.jobs.data.sort((a, b) => b._ts - a._ts) //TODO: sorts jobs by newest first, should be moved to backend

    this.setState({
      company,
      jobs,
      currentJob: jobs[0],
      filteredJobs: jobs.filter(job => job.title.toLowerCase().includes(this.state.query))
    })
  }

  onChange(e) {
    let filteredJobs = this.state.jobs
    filteredJobs = filteredJobs.filter(job => job.title.toLowerCase().includes(e.target.value))
    this.setState({filteredJobs, query: e.target.value})
  }

  onJobClick(job) {
    this.setState({currentJob: job})
  }

  onStageClick(e) {
    this.setState({stage: e.currentTarget.id})
  }

  render() {
    const { query, stage, company, jobs, filteredJobs, currentJob } = this.state
    let groupedByStage = {}
    let stages

    if (currentJob && Object.keys(currentJob).length) {
      stages = [INITIAL_STAGE, ...JSON.parse(currentJob.stages)]
    }

    if (filteredJobs === null) {
      return (
        <BounceLoader
          sizeUnit={"px"}
          size={30}
          className="bounce"
        />
      )
    }

    if (!jobs.length) {
      return (
        <div className="talents">
          <div className="message">
            <h1>
              No jobs found, please post jobs to start tracking!
              <span role="img" aria-label="wave">💼</span>
            </h1>
          </div>
        </div>
      )
    }

    if (currentJob.talents) {
      groupedByStage = groupBy(currentJob.talents.data, talent => {
          let value = talent.stage
          //TEMP code should go away
          try {
            value = JSON.parse(talent.stage).value
          } catch { }
          return value
        }
      )
    }

    return (
      <div className="container">
        <div className="aside">
          <div className="search">
            <input
              type="text"
              placeholder="Search for a job"
              value={query}
              onChange={event => this.onChange(event)}
            />
            <FontAwesomeIcon icon="search" />
            <div className="results">
              {filteredJobs.length} results
            </div>
          </div>
          <div className="list">
            <h3>My jobs</h3>
            { filteredJobs.map(job => (
              <Card key={job._id} job={job} company={company} source="talents" onClick={job => this.onJobClick(job)} />
            ))}
          </div>
        </div>
        <div className="main">
          <h1>{currentJob.title}</h1>
          <div className="options">
            {
              stages.map(s => {
                const className = stage === s.value ? `stage active ${s.className}` : `stage ${s.className}`
                return (
                  <div className={className} key={s.value} id={s.value} onClick={event => this.onStageClick(event)}>
                    <div className="number">
                      { (groupedByStage[s.value] && groupedByStage[s.value].length) || 0 }
                    </div>
                    <div className="name">{s.label}</div>
                  </div>
                )
              })
            }
          </div>
          <div className="table">
            {groupedByStage[stage] && groupedByStage[stage].map((talent, id) => (
              <TalentItem key={id} talent={talent}>{talent.name}</TalentItem>
            ))}
          </div>
        </div>
      </div>
    );
  }
}

export default withApollo(Talents)
