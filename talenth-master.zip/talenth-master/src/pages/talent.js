import React, { Component } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { withApollo } from 'react-apollo'
import { withRouter } from 'react-router-dom'
import { BounceLoader } from 'react-spinners'
import { FIND_COMPANY, ALL_HIRED_TALENTS, FIND_TALENT, UPDATE_TALENT, CREATE_NOTE } from '../queries'

import FileUpload from '../components/base/file_upload'
import TextWithLabel from '../components/base/text_with_label'
import SelectWithLabel from '../components/base/select_with_label'
import Note from '../components/note'

import '../styles/talent.scss'

const FIRST_STAGE = [
  {
    value: 'New Lead',
    label: 'New Lead'
  }
]

const CANDIDATE_STATES = [
  {
    value: 'Active',
    label: 'Active'
  },
  {
    value: 'Archived',
    label: 'Archived'
  }
]

class Talent extends Component {
  state = {
    currentNote: null,
    options: [],
    talent: null
  }

  async componentDidMount() {
    const { client, match } = this.props

    const companyResponse = await client.query({query: FIND_COMPANY})
    const company = companyResponse.data.findCompany

    const talentResponse = await client.query({query: FIND_TALENT, variables: {id: match.params.query}})
    const talent = talentResponse.data.findTalentByID

    const jobOptions = company.jobs.data.map(job => {
      return {
        value: job._id,
        label: job.title
      }
    })

    this.setState({
      talent,
      jobOptions,
      stageOptions: FIRST_STAGE.concat(JSON.parse(talent.job.stages))
    })
  }

  onChange = async e => {
    await this.setState(prevState => ({
      talent: {
        ...prevState.talent,
        [e.currentTarget.id]: e.currentTarget.textContent,
      }
    }))
    this.onSubmit()
  }

  onNoteChange(e) {
    const { value } = e.target
    this.setState({ currentNote: value })
  }

  onStageSelect = async option => {
    await this.setState(prevState => ({
      talent: {
        ...prevState.talent,
        stage: option.value
      },
    }))
    this.onSubmit()
  }

  onStateSelect = async option => {
    await this.setState(prevState => ({
      talent: {
        ...prevState.talent,
        state: option.value
      },
    }))
    this.onSubmit()
  }

  onJobSelect = async option => {
    await this.setState(prevState => ({
      talent: {
        ...prevState.talent,
        job: {
          _id: option.value,
          title: option.label
        }
      },
    }))
    this.onSubmit()
  }

  onFileUpload(file) {
    this.setState(prevState => ({
      talent: {
        ...prevState.talent,
        resume: JSON.stringify(file)
      }
    }))
  }

  async onSubmit() {
    const { client, match } = this.props
    const { talent } = this.state

    const updatedTalent = {
      email: talent.email,
      name: talent.name,
      bio: talent.bio,
      resume: talent.resume,
      job: { connect: talent.job._id },
      state: talent.state,
      stage: talent.stage
    }
    await client.mutate({
      mutation: UPDATE_TALENT,
      variables: { id: match.params.query, talent: updatedTalent },
      refetchQueries: [
        { query: FIND_COMPANY },
        { query: FIND_TALENT, variables: {id: match.params.query} },
        { query: ALL_HIRED_TALENTS }
      ]
    })
  }

  onAddNote = async () => {
    const { client, match, user } = this.props

    const { data } = await client.mutate({
      mutation: CREATE_NOTE,
      variables: {
        note: {
          feedback: "",
          provider: "",
          content: this.state.currentNote,
          owner: user.name,
          talent: { connect: match.params.query }
        }
      }
    })

    const { notes } = this.state.talent
    notes.data.push(data.createNote)

    await this.setState(prevState => ({
      talent: {
        ...prevState.talent,
        notes
      }
    }))
  }

  render() {
    const { talent, stageOptions, jobOptions, currentNote } = this.state

    if (!talent) return (
      <BounceLoader
        sizeUnit={"px"}
        size={30}
        className="bounce"
      />
    )

    return (
      <div className="talent-page">
        <div className="header">
          <h1>{talent.name}</h1>
          <p>{talent.title}</p>
        </div>
        <hr />
        <div className="body">
          <div className="left">
            <SelectWithLabel
              className="job"
              isMulti={false}
              valid={true}
              label="Select candidate job"
              value={{
                value: talent.job._id,
                label: talent.job.title
              }}
              options={jobOptions}
              onChange={selectedOption => this.onJobSelect(selectedOption)}
            />
            {
              talent.notes.data.map(note => {
                return <Note key={note._id} note={note} user={this.props.user} />
              })
            }
            <TextWithLabel
              name="note"
              valid={true}
              label="Note"
              value={currentNote}
              onChange={event => this.onNoteChange(event)}
            />
            <div className="action">
              <button data-cy="add-note" onClick={() => this.onAddNote()} className="button">
                <FontAwesomeIcon icon="plus"/>
                Add Note
              </button>
            </div>
          </div>
          <div className="right">
            <SelectWithLabel
              className="state"
              isMulti={false}
              valid={true}
              label="Select candidate state"
              value={{
                label: talent.state,
                value: talent.state
              }}
              options={CANDIDATE_STATES}
              onChange={selectedOption => this.onStateSelect(selectedOption)}
            />
            <SelectWithLabel
              className="interview-stage"
              isMulti={false}
              valid={true}
              label="Select interview stage"
              value={{
                label: talent.stage,
                value: talent.stage
              }}
              options={stageOptions}
              onChange={selectedOption => this.onStageSelect(selectedOption)}
            />
            <div className="links">
              <ul>
                <li>
                  <FontAwesomeIcon icon="envelope"/>
                  <span>{talent.email}</span>
                </li>
                <li>
                  <FontAwesomeIcon icon="map-marked-alt"/>
                  <span>Location</span>
                </li>
              </ul>
            </div>
            <FileUpload
              name="resume"
              label="Attachments (only .pdf)"
              onFileUpload={file => this.onFileUpload(file)}
            />
            { talent.resume && <p><a href={talent.resume} target="blank">{talent.resume.split('/')[3]}</a></p> }
          </div>
        </div>
      </div>
    )
  }
}

export default withRouter(withApollo(Talent))