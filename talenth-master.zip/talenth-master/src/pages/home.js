import React, { PureComponent, Fragment } from 'react'

import SearchBox from '../components/search_box'
import Map from '../components/map'

class Home extends PureComponent {
  render() {
    return (
      <Fragment>
        <SearchBox />
        <div className="main-view">
          <Map />
        </div>
        <footer>
          <img src="https://www.netlify.com/img/global/badges/netlify-light.svg" alt="netlify"/>
          <span>hi@talenth.co</span>
        </footer>
      </Fragment>
    )
  }
}

export default Home