import React, { PureComponent } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { BounceLoader } from 'react-spinners'
import { withApollo } from 'react-apollo'
import Html from 'slate-html-serializer'

import Card from '../components/talent/card'
import { FIND_COMPANY } from '../queries'
import { RULES } from '../components/base/text_editor_config'

import '../styles/container.scss'

const HTML = new Html({ rules: RULES })

class MyJobs extends PureComponent {
  state = {
    loading: true,
    company: null,
    currentJob: null,
    jobs: [],
    filteredJobs: [],
    query: this.props.match.params.query || ''    
  }

  async componentDidMount() {
    const response = await this.props.client.query({query: FIND_COMPANY})
    const company = response.data.findCompany
    let jobs, filteredJobs, currentJob

    if (company) {
      jobs = company.jobs.data
      filteredJobs = company.jobs.data.filter(job => job.title.toLowerCase().includes(this.state.query))
      currentJob = company.jobs.data[0]
    }

    this.setState({
      loading: false,
      company,
      jobs,
      filteredJobs,
      currentJob
    })
  }

  onJobClick(job) {
    this.setState({currentJob: job})
  }

  onChange(e) {
    let filteredJobs = this.state.jobs
    filteredJobs = filteredJobs.filter(job => job.title.toLowerCase().includes(e.target.value))
    this.setState({filteredJobs, query: e.target.value})
  }

  onShare() {
    console.log('I should share')
  }

  render() {
    const { history } = this.props
    const { loading, query, company, filteredJobs, currentJob } = this.state

    if (loading) return (
      <BounceLoader
        sizeUnit={"px"}
        size={30}
        className="bounce"
      />
    )

    if (!company) {
      return (
        <div className="container">
          <div className="is-hero">
            <div className="message">
              <h1>
                No company found, please add a company to start posting jobs!
                <span role="img" aria-label="wave">🏢</span>
              </h1>
            </div>
            <div className="action">
              <button className="button" onClick={() => history.push('/add_company')}>
                <FontAwesomeIcon icon="plus"/>
                Add Company
              </button>
            </div>
          </div>
        </div>
      )
    }

    if (!company.jobs.data.length) {
      return (
        <div className="container">
          <div className="is-hero">
            <div className="message">
              <h1>
                No jobs found, please post jobs to start tracking!
                <span role="img" aria-label="wave">💼</span>
              </h1>
            </div>
            <div className="action">
              <button className="button" onClick={() => history.push('/post_job')}>
                <FontAwesomeIcon icon="plus"/>
                Post Job
              </button>
            </div>
          </div>
        </div>
      )
    }

    return (
      <div className="container">
        <div className="aside">
          <div className="search">
            <input
              type="text"
              placeholder="Search for a job"
              value={query}
              onChange={event => this.onChange(event)}
            />
            <FontAwesomeIcon icon="search" />
            <div className="results">
              {filteredJobs.length} results
            </div>
          </div>        
          <div className="list">
            <h3>My jobs</h3>
            { filteredJobs.map(job => (
              <Card key={job._id} job={job} company={company} onClick={job => this.onJobClick(job)} />
            ))}  
          </div>
        </div>
        <div className="main">
          <h1 className="job">
            { currentJob.title }
            <div className="action">
              <button className="button primary-button" data-cy="share" onClick={() => this.onShare()}>
                <FontAwesomeIcon icon="share"/>
                Share
              </button>
              <button className="button" data-cy="preview" onClick={() => history.push(`/apply/${currentJob._id}`)}>
                <FontAwesomeIcon icon="eye"/>
                Preview
              </button>
              <button className="button" data-cy="edit" onClick={() => history.push(`/edit_job/${currentJob._id}`)}>
                <FontAwesomeIcon icon="pen"/>
                Edit
              </button>
            </div>
          </h1>
          <div className="body">
            <div dangerouslySetInnerHTML={{__html: HTML.serialize(JSON.parse(currentJob.description))}} />
          </div>
        </div>
      </div>
    )
  }
}

export default withApollo(MyJobs)