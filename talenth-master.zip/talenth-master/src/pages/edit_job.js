import React, { PureComponent } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { withApollo } from 'react-apollo'

import { FIND_JOB, UPDATE_JOB, FIND_COMPANY } from '../queries'

import InputWithLabel from '../components/base/input_with_label'
import SelectWithLabel from '../components/base/select_with_label'
import TextEditor from '../components/base/text_editor'

import { INTERVIEW_STAGES, STATUSES } from '../config/job'

class EditJob extends PureComponent {
  state = {
    isValid: true,
    job: {
      title: '',
      description: '',
      stages: '',
      status: ''
    }
  }

  async componentDidMount() {
    const { match, client } = this.props
    const { data } = await client.query({query: FIND_JOB, variables: {id: match.params.query}})

    this.setState({
      job: {
        status: data.findJobByID.status,
        title: data.findJobByID.title,
        description: JSON.parse(data.findJobByID.description),
        stages: JSON.parse(data.findJobByID.stages)
      }
    })
  }

  onChange(e) {
    const { name, value } = e.target

    this.setState(prevState => ({
      job: {
        ...prevState.job,
        [name]: value,
      },
    }))
  }

  onEditorChange(data) {
    this.setState(prevState => ({
      job: {
        ...prevState.job,
        description: data,
      }
    }))
  }

  onCompleted() {
    this.state.isValid && this.setState({completed: true})
    window.scrollTo(0, 0)
  }

  onStageChange(selectedOption) {
    this.setState(prevState => ({
      job: {
        ...prevState.job,
        stages: selectedOption,
      }
    }))
  }

  onStatusChange(selectedOption) {
    this.setState(prevState => ({
      job: {
        ...prevState.job,
        status: selectedOption.value,
      }
    }))
  }

  async onSubmit() {
    const { job } = this.state
    const { client, match } = this.props

    if (this.isValid()) {
      await client.mutate({
        mutation: UPDATE_JOB,
        variables: {
          id: match.params.query,
          job: {
            ...job,
            description: JSON.stringify(job.description),
            stages: JSON.stringify(job.stages)
          }
        },
        update: (cache, { data: { updateJob } }) => {
          const { findCompany } = cache.readQuery({ query: FIND_COMPANY })
          const updatedJobIndex = findCompany.jobs.data.findIndex(job => job._id === updateJob._id)
          findCompany.jobs.data[updatedJobIndex] = updateJob

          cache.writeQuery({
            query: FIND_COMPANY,
            data: { findCompany }
          })
        }
      })
      this.props.history.push('/my_jobs')
    } else {
      this.setState({isValid: this.isValid()})
      window.scrollTo(0, 0)
    }
  }

  isValid() {
    const { job } = this.state
    return job.title !== '' && job.description !== ''
  }

  render() {
    const { job, isValid } = this.state
    let status

    if (job.status) {
      status = {
        value: job.status,
        label: job.status[0].toUpperCase() + job.status.substr(1)
      }
    }

    return (
      <div className="container">
        <div className="header is-left">
          <h1>Update a job post</h1>
          <p>
            Please fill the form according to your needs.
            Fields marked with "*" are required, make sure to fill them out.
          </p>
        </div>
        <div>
          <hr />
          <div className="body">
            <h3>Job details</h3>
            <div className="cols">
              <div className="left">
                <InputWithLabel 
                  name="title"
                  valid={isValid || job.title !== ''}
                  label="Job title*"
                  value={job.title}
                  onChange={event => this.onChange(event)}
                />
              </div>
              <div className="right">
                <SelectWithLabel
                  valid={true}
                  isCreatable={false}
                  isMulti={false}
                  label="Job status"
                  value={status}
                  options={STATUSES}
                  className="single-select"
                  onChange={selectedOption => this.onStatusChange(selectedOption)}
                />
              </div>
            </div>
            <TextEditor
              name="description"
              value={job.description}
              valid={isValid || job.description !== ''}
              label="Job description*"
              onChange={data => this.onEditorChange(data)}
            />
          </div>
          <hr />
          <div className="body">
            <h3>Interview process</h3>
            <SelectWithLabel
              valid={true}
              isCreatable={true}
              isMulti={true}
              label="Interview stages*"
              value={job.stages}
              options={INTERVIEW_STAGES}
              className="multi-select"
              onChange={selectedOption => this.onStageChange(selectedOption)}
            />
          </div>
        </div>
        <div className="action">
          <button className="button" data-cy="submit" onClick={() => this.onSubmit()}>
            <FontAwesomeIcon icon="rocket"/>
            Submit
          </button>
        </div>
      </div>
    )
  }
}

export default withApollo(EditJob)