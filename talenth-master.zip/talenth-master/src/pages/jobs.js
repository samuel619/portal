import React, { PureComponent } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { withApollo } from 'react-apollo'

import Map from '../components/map'
import JobItem from '../components/job/item'

import { ALL_ACTIVE_JOBS_QUERY } from '../queries'

import '../styles/jobs.scss'

class Jobs extends PureComponent {
  state = {
    currentJob: null,
    jobs: [],
    filteredJobs: [],
    query: this.props.match.params.query || ''
  }

  async componentDidMount() {
    const response = await this.props.client.query({query: ALL_ACTIVE_JOBS_QUERY})

    const data = response.data.allActiveJobs.data.sort((a, b) => b._ts - a._ts) //FIX: sorts jobs by newest first, should be moved to backend
    this.setState({
      jobs: data,
      filteredJobs: data.filter(job => job.title.toLowerCase().includes(this.state.query))
    })
  }

  onOpen(job) {
    this.setState({currentJob: job})
  }

  onChange(e) {
    let filteredJobs = this.state.jobs
    filteredJobs = filteredJobs.filter(job => job.title.toLowerCase().includes(e.target.value))
    this.setState({filteredJobs, query: e.target.value})
  }

  render() {
    const { query, filteredJobs, currentJob } = this.state

    return (
      <div className="jobs">
        <div className="view">
          <div className="search">
            <input
              type="text"
              placeholder="Search for a title"
              value={query}
              onChange={event => this.onChange(event)}
            />
            <FontAwesomeIcon icon="search" />
            <div className="results">
              {filteredJobs.length} results
            </div>
          </div>
          <div className="list">
            { filteredJobs.map(job => (
              <JobItem key={job._id} job={job} onOpen={job => this.onOpen(job)} />
            ))}
          </div>
        </div>
        <Map jobs={filteredJobs} currentJob={currentJob}/>
      </div>
    )
  }
}

export default withApollo(Jobs)
