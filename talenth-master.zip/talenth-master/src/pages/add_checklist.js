import React, { Component } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { withApollo } from 'react-apollo'

import { CREATE_CHECKLIST, ALL_CHECKLIST_TEMPLATES } from '../queries'

import InputWithLabel from '../components/base/input_with_label'
import SelectWithLabel from '../components/base/select_with_label'
import TemplatePreview from '../components/template_preview'

class AddChecklist extends Component {
  state = {
    isValid: true,
    name: '',
    template: '',
    options: []
  }

  async componentDidMount() {
    const { data } = await this.props.client.query({query: ALL_CHECKLIST_TEMPLATES})
    const options = data.allChecklistTemplates.data.map(template => {
      return {
        value: template._id,
        label: template.name,
        data: template
      }
    })

    this.setState({
      options,
      template: options[0]
    })
  }

  onChange(e) {
    this.setState({[e.target.name]: e.target.value})
  }

  onTemplateChange(selectedOption) {
    this.setState({template: selectedOption})
  }

  async onSubmit() {
    const { client, history } = this.props
    const { name, template } = this.state
    const { data } = template

    if (this.isValid()) {
      await client.mutate({
        mutation: CREATE_CHECKLIST,
        variables: {
          checklist: {
            name,
            type: data.type,
            steps: {
              create: data.steps.data.map(step => (
                {
                  name: step.name,
                  content: step.content,
                  actions: {
                    create: step.actions.data.map(action => (
                      {
                        name: action.name,
                        content: action.content,
                        assignee: action.assignee
                      }
                    ))
                  }
                })
              )
            }
          }
        }
      })
      history.push('/checklists')
    } else {
      this.setState({isValid: this.isValid()})
      window.scrollTo(0, 0)
    }
  }

  isValid() {
    const { name } = this.state
    return name !== ''
  }

  render() {
    const { options, name, template, isValid } = this.state

    return (
      <div className="container">
        <div className="header is-left">
          <h1>Add a checklist</h1>
          <p>
            Please select a checklist from our premade templates.
            Fields marked with "*" are required, make sure to fill them out.
          </p>
        </div>
        <hr />
        <div className="body">
          <h3>General info</h3>
          <InputWithLabel
            name="name"
            label="Checklist name*"
            value={name}
            valid={true}
            onChange={event => this.onChange(event)}
          />
          <SelectWithLabel
            isMulti={false}
            valid={isValid || template !== ''}
            label="Premade templates"
            className="single-select"
            value={template}
            options={options}
            onChange={selectedOption => this.onTemplateChange(selectedOption)}
          />
        </div>
        <hr />
        <div className="body wide">
          <TemplatePreview template={template.data} />
        </div>
        <div className="action">
          <button className="button" onClick={() => this.onSubmit()}>
            <FontAwesomeIcon icon="rocket"/>
            Submit
          </button>
        </div>
      </div>
    )
  }
}

export default withApollo(AddChecklist)