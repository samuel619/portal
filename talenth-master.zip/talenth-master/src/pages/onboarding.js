import React, { Component } from 'react'
import { withApollo } from 'react-apollo'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { BounceLoader } from 'react-spinners'
import find from 'lodash.find'

import Card from '../components/talent/card'
import ConnectChecklist from '../components/connect_checklist'
import Checklist from '../components/checklist'

import { ALL_HIRED_TALENTS, UPDATE_TALENT } from '../queries'

import '../styles/base/tile.scss'

class Onboarding extends Component {
  state = {
    currentTalent: null,
    talents: [],
    filteredTalents: [],
    query: '',
    loading: true,
  }

  async componentDidMount() {
    const { data } = await this.props.client.query({query: ALL_HIRED_TALENTS})

    this.setState({
      loading: false,
      talents: data.allHiredTalents.data,
      currentTalent: data.allHiredTalents.data[0],
      filteredTalents: data.allHiredTalents.data.filter(talent => talent.name.toLowerCase().includes(this.state.query))
    })
  }

  onTalentClick(talent) {
    this.setState({currentTalent: talent})
  }

  async onConnect(checklist) {
    const { currentTalent } = this.state
    const { client } = this.props

    const { data } = await client.mutate({
      mutation: UPDATE_TALENT,
      variables: {
        id: currentTalent._id,
        talent: {
          name: currentTalent.name,
          email: currentTalent.email,
          stage: currentTalent.stage,
          checklists: {
            create: [
              {
                name: checklist.data.name,
                type: checklist.data.type,
                steps: {
                  create: checklist.data.steps.data.map(step => (
                    {
                      name: step.name,
                      content: step.content,
                      actions: {
                        create: step.actions.data.map(action => (
                          {
                            name: action.name,
                            content: action.content,
                            assignee: action.assignee
                          }
                        ))
                      }
                    })
                  )
                }
              }
            ]
          }
        }
      }
    })

    this.setState({
      currentTalent: data.updateTalent
    })
  }

  getOnboardingChecklist(talent) {
    return find(talent, {type: 'onboarding'})
  }

  onChange(e) {
    let filteredTalents = this.state.talents
    filteredTalents = filteredTalents.filter(talent => talent.name.toLowerCase().includes(e.target.value))
    this.setState({filteredTalents, query: e.target.value})
  }

  render() {
    const { query, loading, talents, filteredTalents, currentTalent } = this.state

    if (loading) return (
      <BounceLoader
        sizeUnit={"px"}
        size={30}
        className="bounce"
      />
    )

    if (!talents.length) {
      return (
        <div className="container">
          <div className="is-hero">
            <div className="message">
              <h1>
                Please move a candidate to "Hired" stage and start onboarding process!
                <span role="img" aria-label="wave">🤗</span>
              </h1>
            </div>
          </div>
        </div>
      )
    }

    const onboardingChecklist = this.getOnboardingChecklist(currentTalent && currentTalent.checklists.data)
    let view

    if (onboardingChecklist) {
      view = <Checklist talent={currentTalent} template={onboardingChecklist} completable={true}/>
    } else if (currentTalent) {
      view = <ConnectChecklist talent={currentTalent} onConnect={checklist => this.onConnect(checklist)}/>
    }

    return (
      <div className="container">
        <div className="aside">
          <div className="search">
            <input
              type="text"
              placeholder="Search for a hire"
              value={query}
              onChange={event => this.onChange(event)}
            />
            <FontAwesomeIcon icon="search" />
            <div className="results">
              {filteredTalents.length} results
            </div>
          </div>        
          <div className="list">
            <h3>New hires</h3>
            { filteredTalents.map(talent => (
              <Card key={talent._id} talent={talent} onClick={talent => this.onTalentClick(talent)} />
            ))}    
          </div>
        </div>
        { view }
      </div>
    );
  }
}

export default withApollo(Onboarding)
