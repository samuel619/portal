import React, { PureComponent } from 'react'
import { distanceInWordsToNow } from 'date-fns'

import '../../styles/card.scss'

class Card extends PureComponent {
  render() {
    const { job, company, talent, source, onClick } = this.props

    if (job) {
      const status = job.status || 'published'

      if (source === "talents") {
        return (
          <div className="card" onClick={() => onClick(job)}>
            <div className="header">
              <div className="logo">
                <img src={company.logo} alt="logo"/>
              </div>
              <div className="title">
                <h3>
                  {job.title.length > 40 ? job.title.slice(0, 40) + '...' : job.title }
                </h3>
                <p>
                  {company.name}
                </p>
              </div>
              <div className="tag">
                <p className={status}>
                  {status.toUpperCase()}
                </p>
              </div>
              <div className="number">
                <h2>
                  {(job.talents && job.talents.data.length) || 0}
                </h2>
              </div>
            </div>
          </div>
        )
      }
      return (
        <div className="card" onClick={() => onClick(job)}>
          <div className="header">
            <div className="logo">
              <img src={company.logo} alt="logo"/>
            </div>
            <div className="title is-50">
              <h3>
                {job.title.length > 40 ? job.title.slice(0, 40) + '...' : job.title }
              </h3>
              <p>
                {company.name}
              </p>
            </div>
            <div className="details">
              <h3>
                {company.address}
              </h3>
              <p>
                {distanceInWordsToNow(new Date(job._ts/1000))} ago
              </p>
            </div>
          </div>
        </div>
      )
    }

    if (talent) {
      return (
        <div className="card" onClick={() => onClick(talent)}>
          <div className="header">
            <div className="logo">
              <img src='/stormtrooper.png' alt="logo"/>
            </div>
            <div className="title is-50">
              <h3>
                {talent.name}
              </h3>
              <p>
                {talent.job.title}
              </p>
            </div>
            <div className="details">
            </div>
          </div>
        </div>
      )
    }
  }
}

export default Card
