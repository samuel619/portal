import React, { PureComponent } from 'react'
import { Link } from 'react-router-dom'
import Html from 'slate-html-serializer'

import { RULES } from '../base/text_editor_config'

const HTML = new Html({ rules: RULES })

class JobItem extends PureComponent {
  constructor(props, context) {
    super(props, context)
    this.state = {
      showMode: false,
    }
  }

  onToggle() {
    const { job, onJobSelect } = this.props

    this.setState({showMode: !this.state.showMode})
    onJobSelect(job)
  }

  render() {
    const { job, company } = this.props
    const { showMode } = this.state

    const description = HTML.serialize(JSON.parse(job.description))
    const status = job.status || 'published'

    return (
      <div className={job.promoted ? "item promoted" : "item"}>
        <div onClick={() => this.onToggle()} className="header">
          <div className="logo">
            <img src={company.logo} alt="logo"/>
          </div>
          <div className="title">
            <h3>
              {job.title.length > 40 ? job.title.slice(0, 40) + '...' : job.title }
            </h3>
            <p>
              {company.name}
            </p>
          </div>
          <div className="tag">
            <p className={status}>
              {status.toUpperCase()}
            </p>
          </div>
          <div className="number">
            <h2>
              {job.talents.data.length}
            </h2>
          </div>
        </div>
        { showMode &&
          <div className="footer">
            <div className="description">
              <h3>About {company.name}</h3>
              <p>{company.about}</p>
              <h3 className="block">Job Description</h3>
              <div dangerouslySetInnerHTML={{__html: description}} />
            </div>
            <div className="action">
              <Link className="button apply-button" to={`/edit_job/${job._id}`}>
                Edit
              </Link>
              <Link className="button apply-button" to={`/preview/${job._id}`}>
                Preview
              </Link>
            </div>
          </div>
        }
      </div>
    );
  }
}

export default JobItem
