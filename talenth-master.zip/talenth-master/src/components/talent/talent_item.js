import React, { PureComponent } from 'react'
import { withRouter } from 'react-router-dom'

class TalentItem extends PureComponent {

  onClick() {
    const {talent, history} = this.props
    history.push(`/talent/${talent._id}`)
  }

  render() {
    const { talent } = this.props

    return (
      <div className="item" onClick={() => this.onClick()}>
        <div className="name">
          {talent.name}
        </div>
        <div className="title">
          {talent.title}
        </div>
      </div>
    );
  }
}

export default withRouter(TalentItem)