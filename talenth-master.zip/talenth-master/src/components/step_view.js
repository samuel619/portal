import React, { Component } from 'react'
import { withApollo } from 'react-apollo'
import { UPDATE_ACTION } from '../queries'

import Table from '../components/base/table'

class StepView extends Component {
  state = {
    step: this.props.data
  }

  async onComplete(id) {
    const { client } = this.props
    const { step } = this.state

    const actionIndex = step.actions.data.findIndex(x => x._id === id)
    const action = step.actions.data[actionIndex]

    const updatedAction = {
      ...action,
      completed: !action.completed
    }
    let updatedStep = step
    updatedStep.actions.data[actionIndex] = updatedAction

    this.setState({step: updatedStep})

    await client.mutate({
      mutation: UPDATE_ACTION,
      variables: {
        id: action._id,
        action: {
          name: updatedAction.name,
          completed: updatedAction.completed
        }
      }
    })
  }

  render() {
    const { step } = this.state
    const { editable, completable } = this.props

    return (
      <div className="step">
        <h3>
          { step.name }
        </h3>
        <p>
          { step.content }
        </p>
        <Table data={step.actions.data} editable={editable} completable={completable} onComplete={id => this.onComplete(id)} />
      </div>
    )
  }
}

export default withApollo(StepView)
