import React, { PureComponent, Fragment } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'

import '../../styles/base/file_upload.scss'

class FileUpload extends PureComponent {
  state = {
    file: null,
    body: null
  }

  onClick() {
    this.refs.fileUpload.click()
  }

  onDrop(e) {
    const reader = new FileReader()
    const file = e.target.files[0]

    reader.onload = () => {
      this.setState({
        file,
        body: reader.result
      })

      this.props.onFileUpload({
        name: file.name,
        body: reader.result
      })
    }

    reader.readAsDataURL(file)
  }

  render() {
    const { value, label, accept } = this.props
    const { file, body } = this.state
    let preview

    if (file) {
      if (accept === "image/*") {
        preview = <img src={body} alt="logo" />
      } else {
        preview = (
          <ul>
            <li>
              <em>{file.name}</em>
            </li>
          </ul>
        )
      }
    } else {
      if (value) {
        preview = <img src={value} alt="logo" />
      } else {
        preview = (
          <Fragment>
            <FontAwesomeIcon icon="cloud-upload-alt"/>
            <p>Drag & drop or click here</p>
          </Fragment>
        )
      }
    }

    return (
      <div className="input-group">
        <label>{label}</label>
        <div className="attachment">
          <section>
            <div className="dropzone" onClick={() => this.onClick()}>
              <input type="file" accept={accept} ref="fileUpload" style={{display: 'none'}} onChange={event => this.onDrop(event)}/>
              { preview }
            </div>
          </section>
        </div>
      </div>
    )
  }
}

export default FileUpload