import React, { Component } from 'react'
import Select from 'react-select'
import CreatableSelect from 'react-select/creatable'

import '../../styles/base/select.scss'

class SelectWithLabel extends Component {
  render() {
    const {label, value, options, valid, className, isMulti, isCreatable, onChange} = this.props

    if (isCreatable) {
      return (
        <div className="input-group">
          <label>
            {label}
            {!valid && <span className={valid ? '' : 'error'}>This field is required!</span>}
          </label>
          <CreatableSelect
            isMulti={isMulti}
            className={className}
            classNamePrefix="select"
            value={value}
            onChange={selected => onChange(selected)}
            options={options}
          />
        </div>
      )
    } else {
      return (
        <div className="input-group">
          <label>
            {label}
            {!valid && <span className={valid ? '' : 'error'}>This field is required!</span>}
          </label>
          <Select
            isMulti={isMulti}
            placeholder=""
            className={className}
            classNamePrefix="select"
            value={value}
            onChange={selected => onChange(selected)}
            options={options}
          />
        </div>
      )
    }
  }
}

export default SelectWithLabel