import React, { Component, Fragment } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { Link } from 'react-router-dom'
import Html from 'slate-html-serializer'
import { RULES } from './text_editor_config'

import '../../styles/base/table.scss'

const HTML = new Html({ rules: RULES })

class Table extends Component {
  state = {
    expandedRows: {}
  }

  onToggle(row) {
    const { expandedRows } = this.state
    expandedRows[row._id] = !expandedRows[row._id]
    this.setState({expandedRows})
  }

  extractContent(text) { //Should go away once we move to Slate
    let content
    try {
      content = HTML.serialize(JSON.parse(text))
    } catch {
      content = text
    }
    return content
  }

  generateActions(row) {
    const { editable, completable, onComplete } = this.props
    let editAction, completeAction

    if (editable) {
      editAction = (
        <Link className="button apply-button" to={`/edit_action/${row._id}`}>
          Edit
        </Link>
      )
    }

    if (completable) {
      completeAction = (
        <a href="/#" className="button" onClick={() => onComplete(row._id)}>
          {row.completed ? "Start" : "Complete"}
        </a>
      )
    }

    return (
      <div className="action">
        {editAction}
        {completeAction}
      </div>
    )
  }

  render() {
    const { data, editable, completable } = this.props
    const { expandedRows } = this.state

    return (
      <table>
        <tbody>
          {
            data.map((row, index) => (
              <Fragment key={index}>
                <tr className="row" onClick={() => this.onToggle(row)}>
                  <td className="chevron">
                    { expandedRows[row._id] ?
                      <FontAwesomeIcon icon="angle-down" />  :
                      <FontAwesomeIcon icon="angle-right" />
                    }
                  </td>
                  <td>{row.name}</td>
                  <td><span className="tag">{row.assignee}</span></td>
                  { completable ?
                    <td><span className={row.completed ? "completed status" : "in-progress status"}>{ row.completed ? "Completed" : "In Progress" }</span></td> :
                    <td><span className="status"></span></td>
                  }
                </tr>
                { expandedRows[row._id] &&
                  <tr>
                    <td className="details">
                      <div className="html">
                        <div dangerouslySetInnerHTML={{__html: this.extractContent(row.content)}} />
                      </div>
                      { (editable || completable) && this.generateActions(row) }
                    </td>
                  </tr>
                }
              </Fragment>
            ))
          }
        </tbody>
      </table>
    )    
  }
}

export default Table
