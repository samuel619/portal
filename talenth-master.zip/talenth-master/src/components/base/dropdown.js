import React, { Component } from 'react'
import { Link } from 'react-router-dom'

import '../../styles/base/dropdown.scss'

class Dropdown extends Component {
  state = {
    show: false
  }

  onMouseEnter() {
    this.setState({show: true})
  }

  onMouseLeave() {
    this.setState({show: false})
  }

  render() {
    const {name} = this.props.user
    const [firstName, secondName] = name.split(' ')

    return (
      <div className="dropdown-wrapper"
        onMouseEnter={() => this.onMouseEnter()}
        onMouseLeave={() => this.onMouseLeave()}
      >
        <span className="initials">
          {firstName.split('')[0]}
          {secondName && secondName.split('')[0]}
        </span>

        <div className={this.state.show ? "dropdown visible" : "dropdown"}>
          <Link to="/company">
            My company
          </Link>
          <hr />
          <span onClick={() => this.props.onSignOut()}>
            Sign Out
          </span>
        </div>
      </div>
    )
  }
}

export default Dropdown