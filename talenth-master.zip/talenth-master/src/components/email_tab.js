import React, { PureComponent, Fragment } from 'react'
import { withApollo } from 'react-apollo'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import Html from 'slate-html-serializer'

import { RULES } from '../components/base/text_editor_config'

import InputWithLabel from './base/input_with_label'
import TextEditor from './base/text_editor'

import '../styles/email.scss'

const HTML = new Html({ rules: RULES })

class EmailTab extends PureComponent {
  state = {
    email: {}
  }

  onChange(e) {
    const {name, value} = e.target

    this.setState(prevState => ({
      email: {
        ...prevState.email,
        [name]: value,
      }
    }))
  }
  
  onEditorChange(data) {
    this.setState(prevState => ({
      email: {
        ...prevState.email,
        content: data,
      },
    }))
  }

  async sendEmail() {
    const response = await fetch(process.env.REACT_APP_SENDGRID_LAMBDA, {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify({
        ...this.state.email,
        content: HTML.serialize(JSON.parse(this.state.email.content))
      })
    })
  }

  render() {
    const { talent } = this.props
    const { email } = this.state

    return (
      <Fragment>
        <div className="body email">
          <h3>Compose email</h3>
          <InputWithLabel
            name="to"
            label="To"
            value={email.to}
            valid={true}
            onChange={event => this.onChange(event)}
          />
          <InputWithLabel
            name="subject"
            label="Subject"
            value={email.subject}
            valid={true}
            onChange={event => this.onChange(event)}
          />
          <TextEditor
            name="content"
            valid={true}
            onChange={data => this.onEditorChange(data)}
          />
        </div>
        <div className="action">
          <button onClick={() => this.sendEmail()} className="button">
            <FontAwesomeIcon icon="rocket"/>
            Send Email
          </button>
        </div>
      </Fragment>
    )
  }
}

export default withApollo(EmailTab)
