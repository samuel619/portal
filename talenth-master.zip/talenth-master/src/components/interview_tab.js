import React, { PureComponent } from 'react'
import { withApollo } from 'react-apollo'
import { UPDATE_TALENT, FIND_TALENT } from '../queries'

import SelectWithLabel from './base/select_with_label'

const INITIAL_STAGE = {
  value: 'New Lead',
  label: 'New Lead'
}

class InterviewTab extends PureComponent {
  state = {
    numPages: null,
    currentStage: null,
    options: []
  }

  componentDidMount() {
    const { talent } = this.props
    const options = JSON.parse(talent.job.stages)

    this.setState({
      options,
      currentStage: options.find(stage => stage.value === talent.stage) || INITIAL_STAGE
    })
  }

  onStageSelect = option => {
    const {client, talent, id} = this.props

    this.setState({currentStage: option})
    const updatedTalent = {
      email: talent.email,
      name: talent.name,
      stage: option.value
    }

    client.mutate({
      mutation: UPDATE_TALENT,
      variables: {
        id,
        talent: updatedTalent
      },
      update: cache => {
        const talent = cache.readQuery({query: FIND_TALENT, variables: {id}})
        talent.stage = option.value

        cache.writeQuery({
          query: FIND_TALENT,
          data: {talent}
        })
      }
    })
  }

  render() {
    const { options, currentStage } = this.state

    return (
      <div className="body">
        <h3>Interview</h3>
        <SelectWithLabel
          isMulti={false}
          valid={true}
          label="Select interview stage*"
          value={currentStage}
          options={options}
          onChange={selectedOption => this.onStageSelect(selectedOption)}
        />
      </div>
    )
  }
}

export default withApollo(InterviewTab)
