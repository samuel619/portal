import React, { PureComponent } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { Link, withRouter } from 'react-router-dom'

import Dropdown from '../components/base/dropdown'

import '../styles/header.scss'

class Header extends PureComponent {
  render() {
    const {user, onSignOut, location} = this.props

    return (
      <nav className="nav-bar">
        <div className="header-logo">
          <Link to='/'>
            <img src="/talenth-logo-white.svg" alt="logo"/>
          </Link>
        </div>
        <ul className="left">
          { user ?
            <>
              <li>
                <Link className={["/company", "/add_company", "edit_company"].includes(location.pathname)  ? "active nav-button" : "nav-button"} to='/company'>
                  <FontAwesomeIcon icon="home"/>
                  Company
                </Link>
              </li>
              <li>
                <Link className={(location.pathname === "/my_jobs" || location.pathname === "/")  ? "active nav-button" : "nav-button"} to='/my_jobs'>
                  <FontAwesomeIcon icon="briefcase"/>
                  Jobs
                </Link>
              </li>
              <li>
                <Link className={location.pathname === "/talents" ? "active nav-button" : "nav-button"} to='/talents'>
                  <FontAwesomeIcon icon="filter"/>
                  Hiring pipeline
                </Link>
              </li>
              <li>
                <Link className={location.pathname === "/onboarding" ? "active nav-button" : "nav-button"} to='/onboarding'>
                  <FontAwesomeIcon icon="user-plus"/>
                  Onboarding
                </Link>
              </li>
              <li>
                <Link className={location.pathname === "/checklists" ? "active nav-button" : "nav-button"} to='/checklists'>
                  <FontAwesomeIcon icon="tasks"/>
                  Checklists
                </Link>
              </li>
            </>
            :
            <li>
              <Link className="nav-button" to='/jobs'>
                <FontAwesomeIcon icon="briefcase"/>
                Jobs
              </Link>
            </li>
          }
        </ul>
        <ul className="right">
          <li>
            { location.pathname === "/checklists" &&
              <Link className="primary-button" to='/add_checklist'>
                <FontAwesomeIcon icon="plus"/>
                Add Checklist
              </Link>
            }
            { ((location.pathname.match(/^(\/(.+)jobs(.+)?|\/apply.+)$/) || location.pathname === "/") && user) &&
              <Link className="primary-button" to='/post_job'>
                <FontAwesomeIcon icon="plus"/>
                Post Job
              </Link>
            }
            { location.pathname === "/talents" &&
              <Link className="primary-button" to='/add_talent'>
                <FontAwesomeIcon icon="plus"/>
                Add Talent
              </Link>
            }
          </li>
          <li>
            { user ? 
              <Dropdown user={user} onSignOut={() => onSignOut()} /> :
              <Link className="secondary-button" to='/signin'>
                <FontAwesomeIcon icon="sign-in-alt"/>
                Sign In
              </Link>
            }
          </li>
        </ul>
      </nav>
    )
  }
}

export default withRouter(Header)