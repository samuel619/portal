import React, { Component } from 'react'
import GoogleMapReact from 'google-map-react'

import { CUSTOM_STYLE } from '../config/map'
import Marker from './marker'

import '../styles/map.scss'

const mapCenter = {lat: 40.1776135, lng: 44.5087942}

class Map extends Component {
  static defaultProps = {
    center: mapCenter,
    zoom: 14
  }

  render() {
    const {jobs, currentJob, currentPost} = this.props
    let style = {
      position: 'absolute',
      top: '3.75rem',
      right: 0,
      height: 'calc(100vh - 6.75rem)',
      width: '100%'
    }
    let markers = null
    let { center } = this.props

    if (jobs) {
      style.width = 'calc(100% - 650px)';
      style.height = 'calc(100vh - 3.75rem)';
      markers = jobs.map((job, index) => {
        return (
          <Marker
            key={index}
            lat={job.company.latitude}
            lng={job.company.longitude}
          />
        )
      })
      if(currentJob) {
        center = {
          lat: parseFloat(currentJob.company.latitude),
          lng: parseFloat(currentJob.company.longitude)
        }
      }
    } else if(currentPost) {
      style = {height: '350px', width: '880px'}
      center = {
        lat: currentPost.latitude || mapCenter.lat,
        lng: currentPost.longitude || mapCenter.lng
      }
      markers = <Marker lat={currentPost.lat} lng={currentPost.lng} />
    }

    return (
      <div className="mapbox" style={style}>
        <GoogleMapReact
          bootstrapURLKeys={{ key: process.env.REACT_APP_GMAPS_TOKEN }}
          defaultCenter={this.props.center}
          defaultZoom={this.props.zoom}
          center={center}
          options={{styles: CUSTOM_STYLE, fullscreenControl: false}}
        >
          {markers}
        </GoogleMapReact>
      </div>
    )
  }
}

export default Map