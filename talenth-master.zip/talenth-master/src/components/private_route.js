import React, { PureComponent } from 'react'
import { Route, withRouter } from 'react-router-dom'

import SignInBox from '../components/sign_in_box'

class PrivateRoute extends PureComponent {
  render() {
    const { component: Component, onSignIn, ...rest} = this.props

    return (
      <Route {...rest}
        render={props => {
          return this.props.user ?
            <Component {...props} user={this.props.user} /> :
          (
            <div className="body-wrap">
              <header className="site-header"/>
              <main>
                <section className="hero text-center">
                  <div className="container-sm">
                    <div className="hero-inner">
                      <a href="/">
                        <img className="logo" src="/talenth-logo-with-text.svg" alt="logo"/>
                      </a>
                      <div className="hero-browser">
                        <div className="bubble-4 is-revealing">
                          <img src="/bubble-4.svg" alt="bubble"/>
                        </div>
                        <SignInBox onSignIn={data => onSignIn(data)} />
                      </div>
                    </div>
                  </div>
                </section>
              </main>
            </div>
          )
        }}
      />
    )
  }
}

export default withRouter(PrivateRoute)