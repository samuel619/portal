import React, { PureComponent } from 'react'
import SwipeableViews from 'react-swipeable-views'

import HorizontalTimeline from '../components/timeline/horizontal_timeline'
import StepView from '../components/step_view'

import '../styles/base/timeline.scss'

class Checklist extends PureComponent {
  state = {
    value: 0,
    previous: 0,
    minEventPadding: 20,
    maxEventPadding: 120,
    linePadding: 100,
    labelWidth: 100,
    fillingMotionStiffness: 150,
    fillingMotionDamping: 25,
    slidingMotionStiffness: 150,
    slidingMotionDamping: 25
  }

  render() {
    const { template, talent, completable } = this.props
    const { value, fillingMotionStiffness, fillingMotionDamping, labelWidth, linePadding, maxEventPadding, minEventPadding, slidingMotionDamping, slidingMotionStiffness } = this.state
    let header

    if (!template) return null

    if (talent) {
      header = <h1>{talent.name} - {template.name}</h1>
    } else {
      header = <h1>{template.name}</h1>
    }

    return (
      <div className="main">
        { header }
        <div className="body">
          <div className="timeline">
            <HorizontalTimeline
              fillingMotion={{ stiffness: fillingMotionStiffness, damping: fillingMotionDamping }}
              index={value}
              indexClick={(index) => {
                this.setState({ value: index, previous: value })
              }}
              labelWidth={labelWidth}
              linePadding={linePadding}
              maxEventPadding={maxEventPadding}
              minEventPadding={minEventPadding}
              slidingMotion={{ stiffness: slidingMotionStiffness, damping: slidingMotionDamping }}
              values={ template.steps.data }
            />
          </div>
          <div className='section'>
            <SwipeableViews
              index={this.state.value}
              onChangeIndex={(value, previous) => this.setState({ value: value, previous: previous })}
              resistance>
              {
                template.steps.data.map((step, index) => <StepView key={index} data={step} editable={true} completable={completable} />)
              }
            </SwipeableViews>
          </div>
        </div>
      </div>
    )
  }
}

export default Checklist