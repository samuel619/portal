import React, { PureComponent } from 'react'
import SwipeableViews from 'react-swipeable-views'

import HorizontalTimeline from '../components/timeline/horizontal_timeline'
import StepView from '../components/step_view'

import '../styles/base/timeline.scss'

class TemplatePreview extends PureComponent {
  state = {
    value: 0,
    previous: 0,
    minEventPadding: 20,
    maxEventPadding: 120,
    linePadding: 100,
    labelWidth: 100,
    fillingMotionStiffness: 150,
    fillingMotionDamping: 25,
    slidingMotionStiffness: 150,
    slidingMotionDamping: 25
  }

  render() {
    const { template } = this.props
    const { value, fillingMotionStiffness, fillingMotionDamping, labelWidth, linePadding, maxEventPadding, minEventPadding, slidingMotionDamping, slidingMotionStiffness } = this.state

    if (!template) return null

    return (
      <>
        <div className="timeline">
          <HorizontalTimeline
            fillingMotion={{ stiffness: fillingMotionStiffness, damping: fillingMotionDamping }}
            index={value}
            indexClick={(index) => {
              this.setState({ value: index, previous: value })
            }}
            labelWidth={labelWidth}
            linePadding={linePadding}
            maxEventPadding={maxEventPadding}
            minEventPadding={minEventPadding}
            slidingMotion={{ stiffness: slidingMotionStiffness, damping: slidingMotionDamping }}
            values={ template.steps.data }
          />
        </div>
        <div className='section'>
          <SwipeableViews
            index={this.state.value}
            onChangeIndex={(value, previous) => this.setState({ value: value, previous: previous })}
            resistance>
            {
              template.steps.data.map((step, index) => <StepView key={index} data={step} editable={false} completable={false} />)
            }
          </SwipeableViews>
        </div>
      </>
    )
  }
}

export default TemplatePreview