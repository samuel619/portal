import React, { PureComponent } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'

import '../styles/list_item.scss'

class ListItem extends PureComponent {
  render() {
    const { data, onClick } = this.props

    return (
      <div className="list-item" onClick={() => onClick(data)}>
        <div className="header">
          <div className="logo">
            <FontAwesomeIcon icon="tasks" />
          </div>
          <div className="title">
            <h3>
              {data.name}
            </h3>
          </div>
          <div className="tag">
            <p>
              {data.type}
            </p>
          </div>
        </div>
      </div>
    );
  }
}

export default ListItem