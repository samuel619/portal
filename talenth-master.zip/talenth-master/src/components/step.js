import React, { Component } from 'react'
import { withApollo } from 'react-apollo'

import { UPDATE_ACTION } from '../queries'

import '../styles/step.scss'

class Step extends Component {
  state = {
    step: this.props.source
  }

  async onChange(action) {
    const { client, onChange } = this.props
    const { step } = this.state

    const actionIndex = step.actions.data.findIndex(x => x._id === action._id)
    const updatedAction = {
      ...action,
      completed: !action.completed
    }
    let updatedStep = step
    updatedStep.actions.data[actionIndex] = updatedAction

    this.setState({step: updatedStep})
    onChange(updatedStep)

    await client.mutate({
      mutation: UPDATE_ACTION,
      variables: {
        id: action._id,
        action: {
          item: updatedAction.item,
          completed: updatedAction.completed
        }
      }
    })
  }

  render() {
    const { step } = this.state

    return (
      <div className="step">
        <header>
          <p>
            {step.name}
          </p>
        </header>
        <ul>
          {
            step.actions.data.map(action => (
              <li key={action._id}>
                <label>
                  <input
                    type="checkbox"
                    checked={action.completed}
                    onChange={() => this.onChange(action)} />
                  <span className="indicator"></span>
                  {action.item}
                </label>
              </li>
            ))
          }
        </ul>
      </div>
    )
  }
}

export default withApollo(Step)
