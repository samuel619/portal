import React from 'react'
import Radium from 'radium'

const dots = {
  links: {
    position: 'absolute',
    bottom: 0,
    textAlign: 'center',
    paddingBottom: 15,
  }
};


class TimelineDot extends React.Component {
  render() {
    let dotType = 'future'
    if (this.props.index < this.props.selected) {
      dotType = 'past'
    } else if (this.props.index === this.props.selected) {
      dotType = 'present'
    }

    return (
      <li
        key={ this.props.date }
        id={`timeline-dot-${this.props.date}`}
        className={`${dotType} dot-label`}
        onClick={() => this.props.onClick(this.props.index)}
        style={[
          dots.links,
          {
            left: this.props.distanceFromOrigin - this.props.labelWidth / 2,
            cursor: 'pointer',
            width: this.props.labelWidth,
            ':hover': {},
          }
        ]}
      >
        { this.props.label }
        <span className={`dot-dot ${dotType}`}
          key='dot-dot'
          style={{left: this.props.labelWidth / 2 - 6}}
        />
      </li>
    );
  }
}

export default Radium(TimelineDot)
