import React from 'react'

import Radium from 'radium'
import dimensions from 'react-dimensions'

import EventsBar from './events_bar'

class HorizontalTimeline extends React.Component {
  render() {
    const { values, containerWidth, linePadding, containerHeight, index, indexClick, labelWidth, fillingMotion } = this.props

    if (!containerWidth) {
      return false
    }

    const events = values.map((value, index) => ({
      distance: index*250 + 100,
      label: value.name,
      date: value._id,
    }))

    const visibleWidth = containerWidth - 80

    const totalWidth = Math.max(
      events[events.length - 1].distance + linePadding,
      visibleWidth
    )

    let barPaddingRight = 0
    let barPaddingLeft = 0

    return (
      <EventsBar
        width={containerWidth}
        height={containerHeight}
        events={events}
        totalWidth={totalWidth}
        visibleWidth={visibleWidth}
        index={index}
        indexClick={indexClick}
        labelWidth={labelWidth}
        fillingMotion={fillingMotion}
        barPaddingRight={barPaddingRight}
        barPaddingLeft={barPaddingLeft}
      />
    )
  }
}

export default Radium(dimensions({elementResize: true})(HorizontalTimeline))
