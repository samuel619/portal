import React from 'react'
import { Motion, spring } from 'react-motion'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'

import Events from './events'

class EventsBar extends React.Component {
  constructor(props) {
    super(props)

    this.state = {
      position: 0,
      maxPosition: Math.min(props.visibleWidth - props.totalWidth, 0),
    }
  }

  componentDidMount() {
    const selectedEvent = this.props.events[this.props.index]
    this.slideToPosition(-(selectedEvent.distance - (this.props.visibleWidth / 2)), this.props)
  }

  componentWillReceiveProps(props) {
    const selectedEvent = props.events[props.index]
    const minVisible = -this.state.position
    const maxVisible = minVisible + props.visibleWidth

    if (selectedEvent.distance > (minVisible + 10) && selectedEvent.distance < (maxVisible - 10)) {
      this.slideToPosition(this.state.position, props)
    } else {
      this.slideToPosition(-(selectedEvent.distance - (props.visibleWidth / 2)), props)
    }
  }

  slideToPosition = (position, props = this.props) => {
    const maxPosition = Math.min(props.visibleWidth - props.totalWidth, 0)

    this.setState({
      position: Math.max(Math.min(0, position), maxPosition),
      maxPosition
    })
  }

  updateSlide = (direction, props = this.props) => {
    if (direction === 'right') {
      this.slideToPosition((this.state.position - props.visibleWidth) + props.labelWidth, props)
    } else if (direction === 'left') {
      this.slideToPosition((this.state.position + props.visibleWidth) - props.labelWidth, props)
    }
  }

  centerEvent = (index, props = this.props) => {
    const event = props.events[index]
    this.slideToPosition(-event.distance)
  }

  render() {
    const filledValue = this.props.events[this.props.index].distance - this.props.barPaddingLeft
    const eventLineWidth = this.props.totalWidth - this.props.barPaddingLeft - this.props.barPaddingRight

    const buttonBackEnabled = Math.round(this.state.position) < 0
    const buttonForwardEnabled = Math.round(this.state.position) > Math.round(this.state.maxPosition)

    return (
      <div
        style={{
          width: `${this.props.width}px`,
          height: `${this.props.height}px`,
        }}
      >
        <div
          className='events-wrapper'
          style={{
            position: 'relative',
            height: '100%',
            margin: '0 40px',
            overflow: 'hidden'
          }}
        >
          <Motion
            style={{
              X: spring(this.state.position, this.slidingMotion)
            }}
          >{({X}) =>
            <div
              className='events'
              style={{
                position: 'absolute',
                left: 0,
                top: 49,
                height: 2,
                width: this.props.totalWidth,
                WebkitTransform: `translate3d(${X}, 0, 0)px`,
                transform: `translate3d(${X}px, 0, 0)`
              }}
            >
              <Motion style={{
                  tWidth: spring(eventLineWidth, this.props.fillingMotion),
                  tLeft: spring(this.props.barPaddingLeft, this.props.fillingMotion),
                }}>{({tWidth, tLeft}) =>
                  <span
                    aria-hidden='true'
                    className='timeline-eventline'
                    style={{
                      left: `${tLeft}px`,
                      width: `${tWidth}px`,
                      backgroundColor: "#dfdfdf"
                    }}
                  />
                }
              </Motion>
              <Motion style={{
                  tWidth: spring(filledValue, this.props.fillingMotion),
                  tLeft: spring(this.props.barPaddingLeft, this.props.fillingMotion),
                }}>{({tWidth, tLeft}) =>
                  <span
                    aria-hidden='true'
                    className='timeline-eventline'
                    style={{
                      left: `${tLeft}px`,
                      width: `${tWidth}px`
                    }}
                  />
                }
              </Motion>
              <Events
                events={this.props.events}
                selectedIndex={this.props.index}
                handleDateClick={this.props.indexClick}
                labelWidth={this.props.labelWidth}
              />
            </div>
            }</Motion>
          </div>
          <ul style={{ listStyle: 'none' }}>
            <li className="fade left" />
            <li className="fade right" />
          </ul>
          <ul className="buttons">
            <li className={`button-back ${buttonBackEnabled ? 'enabled' : 'disabled'}`}
                onClick={() => this.updateSlide('left')} >
                <FontAwesomeIcon icon="angle-left"/>
            </li>
            <li className={`button-forward ${buttonForwardEnabled ? 'enabled' : 'disabled'}`}
                onClick={() => this.updateSlide('right')} >
                <FontAwesomeIcon icon="angle-right"/>
            </li>
          </ul>
      </div>
    );
  }
}

export default EventsBar
