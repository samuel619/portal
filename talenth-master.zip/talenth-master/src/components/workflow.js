import React, { Component } from 'react'
import { withApollo } from 'react-apollo'
import { BounceLoader } from 'react-spinners'

import Step from './step'

class Workflow extends Component {
  state = {
    currentStage: this.props.workflow.stages.data[0]
  }

  getStageCompletionRate(stage) {
    const currentActions = stage.steps.data.map(step => {
      return step.actions.data
    }).flat()

    const completedActions = currentActions.filter(action => action.completed)

    return Math.round((completedActions.length)*100/(currentActions.length) * 10) / 10
  }

  onStageClick(stage) {
    this.setState({currentStage: stage})
  }

  onStepChange(step) {
    const { currentStage } = this.state

    const stepIndex = currentStage.steps.data.findIndex(x => x._id === step._id)
    currentStage.steps.data[stepIndex] = step

    this.setState({currentStage})
  }

  render() {
    const { talent, workflow } = this.props
    const { currentStage } = this.state

    if (!talent) return (
      <BounceLoader
        sizeUnit={"px"}
        size={30}
        className="bounce"
      />
    )

    return (
      <div className="main">
      <h1>{talent.name} - {workflow.name}</h1>
      <div className="tiles">
        {
          workflow.stages.data.map((stage, index) => {
            const className = stage.name === currentStage.name ? "tile active" : "tile"
            return (
              <div className={className} key={index} onClick={() => this.onStageClick(stage)}>
                <div className="number">
                  {this.getStageCompletionRate(stage)}%
                </div>
                <div className="name">{stage.name}</div>
              </div>
            )
          })
        }
      </div>
      <div className="list">
        {
          currentStage.steps.data.map(step => (
            <Step source={step} key={step._id} onChange={updatedStep => this.onStepChange(updatedStep)} />
          ))
        }
      </div>
    </div>
    )
  }
}

export default withApollo(Workflow)
