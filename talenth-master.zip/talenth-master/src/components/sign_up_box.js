import React, { PureComponent } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { withApollo } from 'react-apollo'
import { Link } from 'react-router-dom'

import { SIGN_UP_USER } from '../queries'
import InputWithLabel from '../components/base/input_with_label'

import '../styles/auth.scss'

class SignUpBox extends PureComponent {
  state = {
    name: '',
    email: this.props.populatedEmail || '',
    password: '',
    isValid: true,
    errors: null
  }

  onChange(e) {
    this.setState({[e.target.name]: e.target.value})
  }

  onClose() {
    this.setState({errors: null})
  }

  async onSubmit() {
    const { name, email, password } = this.state

    if (this.isValid()) {
      try {
        await this.props.client.mutate({
          mutation: SIGN_UP_USER,
          variables: { name, email, password },
          update: (_, { data: { signUp } }) => {
            this.props.onSignUp(signUp)
          }
        })
      } catch(error) {
        if (error.graphQLErrors && error.graphQLErrors.length) {
          this.setState({errors: error.graphQLErrors})
        }
      }
    } else {
      this.setState({isValid: this.isValid()})
      window.scrollTo(0, 0)
    }
  }

  isValid() {
    const { name, email, password } = this.state
    return name !== '' && 
    email !== '' &&
    password !== ''
  }

  render() {
    const { name, email, password, isValid, errors } = this.state

    const errorBox = errors && (
      <div className="errors">
        <FontAwesomeIcon icon="times-circle" onClick={() => this.onClose()}/>
        { errors && errors.map((error, index) => <li key={index}>{error.message}</li>) }
      </div>
    )

    return (
      <div className="auth">
        <div className="header">
          <h1>
            Sign Up
          </h1>
        </div>
        { errorBox }
        <div className="body">
          <InputWithLabel
            name="name"
            label="Full name*"
            value={name}
            valid={isValid || name !== ''}
            onChange={event => this.onChange(event)}
          />
          <InputWithLabel
            name="email"
            label="Email*"
            value={email}
            valid={isValid || email !== ''}
            onChange={event => this.onChange(event)}
          />
          <InputWithLabel
            name="password"
            type="password"
            label="Password*"
            value={password}
            valid={isValid || password !== ''}
            onChange={event => this.onChange(event)}/>
          <div className="input-group">
            <Link to="signin">
              Sign in
            </Link>
            <Link to="password">
              Forgot password
            </Link>
          </div>
        </div>
        <div className="action">
          <button className="button primary-button" onClick={() => this.onSubmit()}>
            <FontAwesomeIcon icon="rocket"/>
            Sign Up
          </button>
        </div>
      </div>
    )
  }
}

export default withApollo(SignUpBox)