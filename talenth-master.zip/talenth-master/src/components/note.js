import React, { PureComponent } from 'react'
import { format } from 'date-fns'

import '../styles/note.scss'

class Note extends PureComponent {
  render() {
    const { note, user } = this.props
    let author, content, feedback, firstName, secondName
    const ts = format(new Date(note._ts/1000), 'MMM D, H:mm')

    if (note.provider === 'slack') {
      author = <img className="logo" src="/slack.png" alt="logo"/>
      feedback = note.feedback === 'hire' ? '👍' : note.feedback === 'no_hire' ? '👎' : '👉'
      content = (
        <div className="content">
          <b>{note.owner} {feedback}</b>
          <br />
          <span>{note.content}</span>
        </div>
      )
    } else {
      [firstName, secondName] = user.name.split(' ')
      author = (
        <span className="initials">
          {firstName.split('')[0]}
          {secondName && secondName.split('')[0]}
        </span>
      )
      content = <div className="content">{note.content}</div>
    }

    return (
      <article className="message">
        <div className="message-author">
          {author}
        </div>          
        <div className="message-body">
          {content}
          <small className="time">
            <em>{ts}</em>
          </small>
        </div>
      </article>
    )
  }
}

export default Note
