import React, { Component } from 'react'
import { withApollo } from 'react-apollo'
import { BounceLoader } from 'react-spinners'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'

import { ALL_CHECKLISTS } from '../queries'

import SelectWithLabel from '../components/base/select_with_label'
import TemplatePreview from '../components/template_preview'

class ConnectChecklist extends Component {
  state = {
    currentChecklist: null,
    checklistOptions: []
  }

  async componentDidMount() {
    const { talent } = this.props

    if (talent) {
      const { data } = await this.props.client.query({query: ALL_CHECKLISTS})

      const checklistOptions = data.allChecklists.data.map(checklist => {
        return {
          value: checklist._id,
          label: checklist.name,
          data: checklist
        }
      })

      this.setState({checklistOptions})
    }
  }

  onChecklistChange(selectedOption) {
    this.setState({
      currentChecklist: selectedOption
    })
  }

  render() {
    const { talent, onConnect } = this.props
    const { currentChecklist, checklistOptions } = this.state

    if (!talent) return (
      <BounceLoader
        sizeUnit={"px"}
        size={30}
        className="bounce"
      />
    )

    return (
      <div className="main">
        <h1>{talent.name}</h1>
        <div className="connect">
          <SelectWithLabel
            valid={true}
            isCreatable={false}
            isMulti={false}
            label="Select an onboarding checklist"
            value={currentChecklist}
            options={checklistOptions}
            className="single-select"
            onChange={selectedOption => this.onChecklistChange(selectedOption)}
          />
          <div className="action">
            <button className="button primary-button" onClick={() => onConnect(currentChecklist)}>
              <FontAwesomeIcon icon="plug"/>
              Connect
            </button>
          </div>
        </div>
        {
          currentChecklist &&
          <div className="body">
            <h3>Checklist Preview</h3>
            <TemplatePreview template={currentChecklist.data} />
          </div>
        }
      </div>
    )
  }
}

export default withApollo(ConnectChecklist)
