import React, { PureComponent } from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { withApollo } from 'react-apollo'
import { Link } from 'react-router-dom'

import { SIGN_IN_USER } from '../queries'
import InputWithLabel from '../components/base/input_with_label'

import '../styles/auth.scss'

class SignInBox extends PureComponent {
  state = {
    email: '',
    password: '',
    isValid: true,
    errors: null
  }

  onChange(e) {
    this.setState({[e.target.name]: e.target.value})
  }

  onClose() {
    this.setState({errors: null})
  }

  async onSubmit() {
    const {email, password} = this.state

    if (this.isValid()) {
      try {
        await this.props.client.mutate({
          mutation: SIGN_IN_USER,
          variables: { email, password },
          update: (_, { data: { signIn } }) => {
            this.props.onSignIn(signIn)
          }
        })
      } catch(error) {
        if (error.graphQLErrors && error.graphQLErrors.length) {
          this.setState({errors: error.graphQLErrors})
        }
      }
    } else {
      this.setState({isValid: this.isValid()})
      window.scrollTo(0, 0)
    }
  }

  isValid() {
    const {email, password} = this.state
    return email !== '' &&
    password !== ''
  }

  render() {
    const { email, password, isValid, errors } = this.state

    const errorBox = errors && (
      <div className="errors">
        <FontAwesomeIcon icon="times-circle" onClick={() => this.onClose()}/>
        { errors && errors.map((error, index) => <li key={index}>{error.message}</li>) }
      </div>
    )

    return (
      <div className="auth">
        <div className="header">
          <h1>
            Sign In
          </h1>
        </div>
        { errorBox }
        <div className="body">
          <InputWithLabel
            name="email"
            label="Email*"
            value={email}
            valid={isValid || email !== ''}
            onChange={event => this.onChange(event)}
          />
          <InputWithLabel
            name="password"
            type="password"
            label="Password*"
            value={password}
            valid={isValid || password !== ''}
            onChange={event => this.onChange(event)}/>
          <div className="input-group">
            <Link to="password">
              Forgot password
            </Link>
          </div>
        </div>
        <div className="action">
          <button className="button primary-button" onClick={() => this.onSubmit()}>
            <FontAwesomeIcon icon="rocket"/>
            Sign in
          </button>
        </div>
      </div>
    )
  }
}

export default withApollo(SignInBox)