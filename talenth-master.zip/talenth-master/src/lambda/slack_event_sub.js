import { GraphQLClient } from 'graphql-request'
import { WebClient } from '@slack/web-api'

import { findTalentByID } from './utils/queries/talent'

const client = new GraphQLClient(process.env.FAUNADB_API, {
  headers: {
    authorization: `Bearer ${process.env.FAUNADB_KEY}`,
  }
})

const slack = new WebClient(process.env.SLACK_CLIENT_TOKEN)

exports.handler = e => {
  console.log('received event...')
  const body = JSON.parse(e.body)

  if (body.type === "url_verification") {
    return {
      statusCode: 200,
      body: body.challenge
    }
  }

  const { event } = body
  const { links } = event

  links.map(link => {
    if (link.url.includes('talent/')) {
      const splittedUrl = link.url.split('/')
      const id = splittedUrl[splittedUrl.length - 1]

      unfurlTalentLink(event, link, id)
    }
  })

  return {
    statusCode: 200
  }
}

const unfurlTalentLink = async (event, link, id) => {
  const talent = await client.request(findTalentByID, {id})

  const { url } = link
  let unfurls

  if (talent.findTalentByID) {
    const stage = JSON.parse(talent.findTalentByID.stage).label

    unfurls = {
      [url]: {
        color: "#22C7A9",
        blocks: [
          {
            type: "section",
            text: {
              type: "mrkdwn",
              text: `You have a new candidate:\n*<${url}|${talent.findTalentByID.name} - ${talent.findTalentByID.job.title}>*`
            }
          },
          {
            type: "section",
            fields: [
              {
                type: "mrkdwn",
                text: "*Location:*\nYerevan, Armenia"
              },
              {
                type: "mrkdwn",
                text: `*Stage:*\n${stage}`
              }
            ]
          },
          {
            type: "actions",
            elements: [
              {
                type: "button",
                style: "primary",
                action_id: "addFeedback",
                value: id,
                text: {
                  type: "plain_text",
                  emoji: true,
                  text: "Submit a feedback"
                }
              }
            ]
          }
        ]
      }
    }
  } else {
    unfurls = {
      [url]: {
        text: "Talent not found :("
      }
    }    
  }

  await slack.chat.unfurl({
    channel: event.channel,
    ts: event.message_ts,
    unfurls
  })
}