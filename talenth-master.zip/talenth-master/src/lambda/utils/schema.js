import gql from 'graphql-tag'

export const typeDefs = gql`
  scalar Long

  input CompanyJobsRelation {
    create: [JobInput]
    connect: [ID]
    disconnect: [ID]
  }

  input CompanyInput {
    name: String!
    about: String!
    website: String
    address: String!
    latitude: Float!
    longitude: Float!
    logo: String!
    email: String!
    jobs: CompanyJobsRelation
    user: CompanyUserRelation
  }

  input ChecklistInput {
    name: String!
    type: String!
    steps: ChecklistStepsRelation
    user: ChecklistUserRelation
    talent: ChecklistTalentRelation
  }

  input JobCompanyRelation {
    create: CompanyInput
    connect: ID
  }

  input TalentChecklistsRelation {
    create: [ChecklistInput]
    connect: [ID]
    disconnect: [ID]
  }

  input TalentUserRelation {
    create: UserInput
    connect: ID
  }

  input JobInput {
    status: String
    title: String!
    description: String!
    stages: String!
    company: JobCompanyRelation
  }

  input ApplicationInput {
    name: String!
    email: String!
    notes: String
    resume: String
    job: ApplicationJobRelation
  }

  input TalentInput {
    name: String!
    title: String
    stage: String!
    state: String
    notes: TalentNotesRelation
    resume: String
    email: String!
    job: TalentJobRelation
    checklists: TalentChecklistsRelation
    user: TalentUserRelation
  }

  input UserInput {
    name: String!
    email: String!
    password: String!
  }

  input SignUpInput {
    name: String!
    email: String!
    password: String!
  }

  input SignInInput {
    email: String!
    password: String!
  }

  input StepInput {
    name: String!
    content: String
    checklistTemplate: StepChecklistTemplateRelation
    actions: StepActionsRelation
  }

  input ActionInput {
    step: ActionStepRelation
    name: String!
    content: String
    assignee: String
    data: String
    completed: Boolean
  }

  input NoteInput {
    feedback: String
    provider: String
    content: String
    owner: String!
    talent: NoteTalentRelation
  }

  input ApplicationJobRelation {
    connect: ID
  }

  input CompanyUserRelation {
    create: UserInput
    connect: ID
    disconnect: Boolean
  }

  input TalentJobRelation {
    connect: ID
  }

  input ActionStepRelation {
    create: StepInput
    connect: ID
  }

  input ChecklistTemplateStepsRelation {
    create: [StepInput]
    connect: [ID]
    disconnect: [ID]
  }

  input StepChecklistTemplateRelation {
    create: ChecklistTemplateInput
    connect: ID
  }

  input StepActionsRelation {
    create: [ActionInput]
    connect: [ID]
    disconnect: [ID]
  }

  input WorkflowTalentRelation {
    create: TalentInput
    connect: ID
  }

  input WorkflowUserRelation {
    create: UserInput
    connect: ID
  }

  input TalentNotesRelation {
    create: [NoteInput]
    connect: [ID]
    disconnect: [ID]
  }

  input NoteTalentRelation {
    create: TalentInput
    connect: ID
  }

  input ChecklistStepsRelation {
    create: [StepInput]
    connect: [ID]
    disconnect: [ID]
  }

  input ChecklistTalentRelation {
    create: TalentInput
    connect: ID
    disconnect: Boolean
  }

  input ChecklistUserRelation {
    create: UserInput
    connect: ID
  }

  input ChecklistTemplateInput {
    name: String!
    type: String!
    steps: ChecklistTemplateStepsRelation
  }

  type User {
    _id: ID!
    _ts: Long!
    name: String!
    email: String!
    password: String!
    company: Company
  }

  type AuthResponse {
    token: String!
    user: User!
  }

  type Company {
    _id: ID!
    _ts: Long!
    website: String
    name: String!
    latitude: Float!
    email: String!
    address: String!
    about: String!
    longitude: Float!
    logo: String!
    jobs: JobPage!
    user: User
  }

  type Job {
    _id: ID!
    _ts: Long!
    status: String
    description: String!
    stages: String!
    title: String!
    company: Company
    talents: TalentPage
  }

  type ChecklistTemplate {
    _id: ID!
    _ts: Long!
    name: String!
    type: String!
    steps: StepPage!
  }

  type Checklist {
    _id: ID!
    _ts: Long!
    name: String!
    type: String!
    steps: StepPage!
    user: User
    talent: Talent
  }

  type CompanyPage {
    data: [Company]!
    after: String
    before: String
  }

  type JobPage {
    data: [Job]!
    after: String
    before: String
  }

  type TalentPage {
    data: [Talent]
    after: String
    before: String
  }

  type NotePage {
    data: [Note]!
    after: String
    before: String
  }

  type ChecklistTemplatePage {
    data: [ChecklistTemplate]!
    after: String
    before: String
  }

  type StepPage {
    data: [Step]!
    after: String
    before: String
  }

  type ActionPage {
    data: [Action]!
    after: String
    before: String
  }

  type ChecklistPage {
    data: [Checklist]!
    after: String
    before: String
  }

  type Application {
    _id: ID!
    _ts: Long!
    name: String!
    resume: String
    notes: String
    email: String!
    job: Job!
  }

  type Talent {
    _id: ID!
    _ts: Long!
    name: String!
    title: String
    email: String!
    stage: String!
    state: String
    notes: NotePage!
    resume: String
    job: Job!
    checklists: ChecklistPage!
    user: User!
  }

  type Note {
    _id: ID!
    _ts: Long!
    provider: String
    talent: Talent!
    feedback: String
    content: String
    owner: String!
  }

  type Step {
    _id: ID!
    name: String!
    content: String
    actions: ActionPage!
  }

  type Action {
    _id: ID!
    _ts: Long!
    data: String
    content: String
    name: String!
    assignee: String
    step: Step!
    completed: Boolean
  }

  type Token {
    name: String
    email: String
  }

  type Query {
    validateToken: Token
    findCompany: Company
    allActiveJobs: JobPage!
    findJobByID(id: ID!): Job
    allTalents: TalentPage!
    allHiredTalents: TalentPage!
    allChecklistTemplates: ChecklistTemplatePage!
    allChecklists: ChecklistPage!
    findTalentByID(id: ID!): Talent
    findActionByID(id: ID!): Action
  }

  type Mutation {
    createCompany(data: CompanyInput!): Company!
    updateCompany(id: ID! data: CompanyInput!): Company!
    createJob(data: JobInput!): Job!
    updateJob(id: ID! data: JobInput!): Job!
    createApplication(data: ApplicationInput!): Application!
    addTalent(data: TalentInput!): Talent!
    createNote(data: NoteInput!): Note!
    updateTalent(id: ID! data: TalentInput!): Talent!
    signUp(data: SignUpInput!): AuthResponse!
    signIn(data: SignInInput!): AuthResponse!
    updateStep(id: ID! data: StepInput!): Step
    updateAction(id: ID! data: ActionInput!): Action
    createChecklist(data: ChecklistInput!): Checklist!
  }
`