export const createUser = `
  mutation SignUpUser(
    $name: String!,
    $email: String!,
    $password: String!
  ) {
    createUser(data: {
      name: $name
      email: $email
      password: $password
    }) {
      _id
      name
      email
    }
  }
`

export const findUserByEmail = `
  query SignInUser($email: String!) {
    findUserByEmail(email: $email) {
      _id
      name
      email
      password
    }
  }
`

export const findUserByID = `
  query FindUserByID($id: ID!) {
    findUserByID(id: $id) {
      company {
        _id
        name
        about
        website
        email
        logo
        address
        latitude
        longitude
        jobs {
          data {
            _id
            _ts
            title
            status
            description
            stages
            talents {
              data {
                _id
                name
                title
                email
                stage
              }
            }
          }
        }
      }
    }
  }
`