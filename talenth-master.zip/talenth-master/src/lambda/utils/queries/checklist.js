export const updateStep = `
  mutation UpdateAStep($id: ID!, $step: StepInput!) {
    updateStep(id: $id data: $step) {
      _id
      name
      actions {
        data {
          _id
          item
          completed
        }
      }
    }
  }
`

export const findActionByID = `
  query FindActionByID($id: ID!) {
    findActionByID(id: $id) {
      name
      assignee
      content
    }
  }
`


export const updateAction = `
  mutation UpdateAnAction($id: ID!, $action: ActionInput!) {
    updateAction(id: $id data: $action) {
      _id
      completed
    }
  }
`

export const allChecklistTemplates = `
  query AllChecklistTemplates {
    allChecklistTemplates {
      data {
        _id
        _ts
        name
        type
        steps {
          data {
            _id
            name
            content
            actions {
              data {
                _id
                name
                content
                assignee
                data
              }
            }
          }
        }
      }
    }
  }
`

export const allChecklists = `
  query AllChecklists {
    allChecklists {
      data {
        _id
        _ts
        name
        type
        steps {
          data {
            _id
            name
            content
            actions {
              data {
                _id
                name
                content
                assignee
                data
              }
            }
          }
        }
        talent {
          _id
        }
        user {
          _id
        }
      }
    }
  }
`

export const createChecklist = `
  mutation CreateAChecklist($checklist: ChecklistInput!) {
    createChecklist(data: $checklist) {
      _id
    }
  }
`