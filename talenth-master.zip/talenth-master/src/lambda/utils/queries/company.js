export const createCompany = `
  mutation CreateACompany($company: CompanyInput!) {
    createCompany(data: $company) {
      _id
      name
      about
      website
      email
      logo
      address
      latitude
      longitude
    }
  }
`

export const updateCompany = `
  mutation UpdateACompany($id: ID!, $company: CompanyInput!) {
    updateCompany(id: $id data: $company) {
      _id
      name
      about
      website
      email
      logo
      address
      latitude
      longitude
    }
  }
`