export const allActiveJobs = `
  query AllActiveJobs {
    allActiveJobs(status: "published") {
      data {
        _id
        _ts
        title
        description
        company {
          name
          about
          logo
          address
          latitude
          longitude
        }
      }
    }
  }
`


export const allMyJobs = `
  query AllMyJobs($id: ID!) {
    findUserByID(id: $id) {
      company {
        _id
        name
        about
        website
        email
        logo
        address
        latitude
        longitude
        jobs {
          data {
            _id
            _ts
            title
            status
            description
            stages
            company {
              _id
              name
              about
              website
              email
              logo
              address
              latitude
              longitude
            }
          }
        }
      }
    }
  }
`

export const findJobByID = `
  query FindJobByID($id: ID!) {
    findJobByID(id: $id) {
      status
      title
      description
      stages
      company {
        _id
        logo
        name
        address
        latitude
        longitude
        email
        about
        jobs {
          data {
            _id
            _ts
            title
          }
        }
      }
    }
  }
`

export const createJob = `
  mutation CreateAJob($job: JobInput!) {
    createJob(data: $job) {
      _id
      _ts
      title
      description
      talents {
        data {
          _id
        }
      }
    }
  }
`

export const updateJob = `
  mutation UpdateAJob($id: ID!, $job: JobInput!) {
    updateJob(id: $id data: $job) {
      _id
      _ts
      title
      status
      description
      stages
      company {
        name
        about
        logo
        address
        latitude
        longitude
      }
      talents {
        data {
          _id
        }
      }
    }
  }
`