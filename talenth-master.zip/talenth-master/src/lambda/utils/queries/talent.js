export const allHiredTalents = `
  query AllHiredTalents($userId: ID!) {
    allHiredTalents(userId: $userId) {
      data {
        _id
        name
        email
        stage
        job {
          _id
          title
        }
        checklists {
          data {
            _id
            _ts
            name
            type
            steps {
              data {
                _id
                name
                content
                actions {
                  data {
                    _id
                    name
                    content
                    assignee
                    completed
                    data
                  }
                }
              }
            }
          }
        }
      }
    }
  }
`

export const findTalentByID = `
  query FindTalentByID($id: ID!) {
    findTalentByID(id: $id) {
      name
      email
      title
      resume
      stage
      state
      notes {
        data {
          _id
          _ts
          feedback
          provider
          content
          owner
        }
      }
      job {
        _id
        title
        stages
      }
    }
  }
`

export const addTalent = `
  mutation CreateATalent($talent: TalentInput!) {
    createTalent(data: $talent) {
      _id
      email
      name
      title
      stage
    }
  }
`

export const updateTalent = `
  mutation UpdateTalent($id: ID!, $talent: TalentInput!) {
    updateTalent(id: $id data: $talent) {
      _id
      name
      title
      email
      resume
      stage
      job {
        _id
        stages
      }
      checklists {
        data {
          _id
          _ts
          name
          type
          steps {
            data {
              _id
              name
              content
              actions {
                data {
                  _id
                  name
                  content
                  assignee
                  data
                }
              }
            }
          }
        }
      }
    }
  }
`

export const createNote = `
  mutation CreateANote($note: NoteInput!) {
    createNote(data: $note) {
      _id
      _ts
      feedback
      provider
      content
      owner
    }
  }
`