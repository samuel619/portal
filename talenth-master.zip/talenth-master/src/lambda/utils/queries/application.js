export const createApplication = `
  mutation CreateAnApplication($application: ApplicationInput!) {
    createApplication(data: $application) {
      _id
    }
  }
`