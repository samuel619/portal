import { WebClient } from '@slack/web-api'
import { GraphQLClient } from 'graphql-request'
import queryString from 'query-string'

import { createNote } from './utils/queries/talent'

const client = new GraphQLClient(process.env.FAUNADB_API, {
  headers: {
    authorization: `Bearer ${process.env.FAUNADB_KEY}`,
  }
})

const slack = new WebClient(process.env.SLACK_CLIENT_TOKEN)

exports.handler = event => {
  const rawBody = queryString.parse(event.body)
  const payload = JSON.parse(rawBody['payload'])

  switch (payload.type) {
    case "block_actions":
      openFeedbackDialog(payload)
      break
    case "dialog_submission":
      submitFeedback(payload)
      break
    default:
  }

  return {
    statusCode: 200
  }
}

const openFeedbackDialog = payload => {
  const { actions } = payload
  const addFeedback = actions.find(action => action.action_id === "addFeedback")

  const dialogData = JSON.stringify({
    title: "Submit a feedback",
    callback_id: "add_feedback",
    submit_label: "Submit",
    state: addFeedback.value,
    elements: [
      {
        type: "textarea",
        name: "content",
        label: "Note"
      },
      {
        label: "Hire/No hire?",
        type: "select",
        name: "feedback",
        options: [
          {
            label: "👍 Hire!",
            value: "hire"
          },
          {
            label: "👉 will go with the team",
            value: "neutral"
          },
          {
            label: "👎 no hire!",
            value: "no_hire"
          }
        ]
      }
    ]
  })

  slack.dialog.open({
    trigger_id: payload.trigger_id,
    dialog: dialogData
  })
}

const submitFeedback = payload => {
  const { submission, user, state } = payload

  const data = {
    feedback: submission.feedback,
    provider: "slack",
    content: submission.content,
    owner: user.name,
    talent: { connect: state }
  }

  client.request(createNote, { note: data })
}