const client = require("@sendgrid/client")

exports.handler = async event => {
  const body = JSON.parse(event.body)
  client.setApiKey(process.env.SENDGRID_API_KEY)

  const data = {
    from: {
      email: "hire@talenth.co", 
      name: "Hire Talenth"
    },
    personalizations: [
      {
        subject: body.subject, 
        to: [
          {
            email: body.to
          }
        ]
      }
    ],
    reply_to: {
      email: "hire@talenth.co", 
      name: "Hire Talenth"
    },
    subject: body.subject,
    content: [
      {
        type: "text/html", 
        value: body.content
      }
    ]
  }

  const request = {
    method: "POST",
    url: "/v3/mail/send",
    body: data
  }

  const response = await client.request(request)

  return {
    statusCode: response[0].statusCode,
    body: response[0].statusMessage
  }
}
