import { ApolloServer, AuthenticationError } from 'apollo-server-lambda'
import { GraphQLClient } from 'graphql-request'
import { typeDefs } from './utils/schema'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import aws from 'aws-sdk/clients/s3'

import { findUserByID, findUserByEmail } from './utils/queries/user'
import { allActiveJobs, findJobByID, createJob, updateJob } from './utils/queries/job'
import { allHiredTalents, findTalentByID, addTalent, updateTalent, createNote } from './utils/queries/talent'
import { createCompany, updateCompany } from './utils/queries/company'
import { allChecklistTemplates, allChecklists, createChecklist, updateStep, updateAction, findActionByID } from './utils/queries/checklist'
import { createApplication } from './utils/queries/application'

const client = new GraphQLClient(process.env.FAUNADB_API, {
  headers: {
    authorization: `Bearer ${process.env.FAUNADB_KEY}`,
  }
})

const s3 = new aws({
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY_ID,
    secretAccessKey: process.env.S3_SECRET_ACCESS_KEY_ID,
  }
})

const getUser = token => {
  try {
    if (token) {
      return jwt.verify(token, process.env.SECRET_TOKEN)
    }
    return null
  } catch (err) {
    return null
  }
}

const generateToken = user => {
  return jwt.sign(
    {
      id: user._id,
      name: user.name,
      email: user.email,
    },
    process.env.SECRET_TOKEN,
    {
      expiresIn: '30d',
    },
  )
}

const authenticate = context => {
  if (!context.user) {
    throw new AuthenticationError('Invalid Login')
  }
}

const resolvers = {
  Query: {
    validateToken: async (_, args, context) => {
      if (context.user) {
        return {
          name: context.user.name,
          email: context.user.email
        }
      } else {
        return null
      }
    },
    allActiveJobs: async () => {
      const response = await client.request(allActiveJobs)
      return response.allActiveJobs
    },
    findJobByID: async (_, args) => {
      const response = await client.request(findJobByID, {id: args.id})
      return response.findJobByID
    },
    allChecklists: async (_, args, context) => {
      authenticate(context)

      const response = await client.request(allChecklists)
      return {
        data: response.allChecklists.data.filter(template => template.talent === null && template.user && template.user._id === context.user.id)
      }
    },
    allChecklistTemplates: async () => {
      const response = await client.request(allChecklistTemplates)
      return response.allChecklistTemplates
    },
    allHiredTalents: async (_, args, context) => {
      authenticate(context)

      const response = await client.request(allHiredTalents, {userId: context.user.id})
      return response.allHiredTalents
    },
    findTalentByID: async (_, args) => {
      const response = await client.request(findTalentByID, {id: args.id})
      return response.findTalentByID
    },
    findActionByID: async (_, args) => {
      const response = await client.request(findActionByID, {id: args.id})
      return response.findActionByID
    },
    findCompany: async (_, args, context) => {
      authenticate(context)

      const response = await client.request(findUserByID, {id: context.user.id})
      return response.findUserByID.company
    }    
  },
  Mutation: {
    signUp: async (_, args) => {
      // const hashedPass = await bcrypt.hash(args.data.password, 10)

      // const variables = {
      //   name: args.data.name,
      //   email: args.data.email,
      //   password: hashedPass
      // }

      // const response = await client.request(createUser, variables)

      // const user = response.createUser
      // const token = generateToken(user)
      // delete user.password

      // return {
      //   token,
      //   user
      // }
      return {
        message: "Sign up access is restricted for now"
      }
    },
    signIn: async (_, args) => {
      const variables = {
        email: args.data.email
      }

      const response = await client.request(findUserByEmail, variables)
      const user = response.findUserByEmail
      if (!user) {
        throw new AuthenticationError('Invalid login')
      }

      const passwordMatch = await bcrypt.compare(args.data.password, user.password)
      if (!passwordMatch) {
        throw new AuthenticationError('Invalid login')
      }

      const token = generateToken(user)
      delete user.password

      return {
        token,
        user
      }
    },
    createJob: async (_, args, context) => {
      authenticate(context)

      const { data } = args

      const user = await client.request(findUserByID, {id: context.user.id})
      data.company = { connect: user.findUserByID.company._id }

      const response = await client.request(createJob, {job: data})
      return response.createJob
    },
    updateJob: async (_, args, context) => {
      authenticate(context)

      const { data } = args

      const response = await client.request(updateJob, {id: args.id, job: data})
      return response.updateJob
    },
    createApplication: async (_, args) => {
      const { data } = args

      if (data.resume) {
        const resume = JSON.parse(data.resume)
        const buf = new Buffer(resume.body.replace(/^data:application\/\w+;base64,/, ""),'base64')

        const params = {
          Bucket: 'talenth',
          Key: resume.name,
          Body: buf,
        }
        let uploadPromise = await s3.upload(params).promise()
        data.resume = uploadPromise.Location
      }

      const response = await client.request(createApplication, {application: data})
      return response.createApplication
    },
    addTalent: async (_, args, context) => {
      authenticate(context)

      const { data } = args

      if (data.resume) {
        const resume = JSON.parse(data.resume)
        const buf = new Buffer(resume.body.replace(/^data:application\/\w+;base64,/, ""),'base64')

        const params = {
          Bucket: 'talenth',
          Key: resume.name,
          Body: buf,
        }
        let uploadPromise = await s3.upload(params).promise()
        data.resume = uploadPromise.Location
      }
      data.user = { connect: context.user.id }

      const response = await client.request(addTalent, {talent: data})
      return response.createTalent
    },
    updateTalent: async (_, args) => {
      const { data } = args

      if (data.resume && !data.resume.includes('https')) {
        const resume = JSON.parse(data.resume)
        const buf = new Buffer(resume.body.replace(/^data:application\/\w+;base64,/, ""),'base64')

        s3.putObject({
          Bucket: 'talenth',
          Key: resume.name,
          Body: buf,
        }, function(err, data) {
          console.log(err, data)
        })
        data.resume = `https://talenth.s3.amazonaws.com/${resume.name}`
      }

      const response = await client.request(updateTalent, {id: args.id, talent: data})
      return response.updateTalent
    },
    updateStep: async (_, args) => {
      const { data } = args

      const response = await client.request(updateStep, {id: args.id, step: data})
      return response.updateStep
    },
    updateAction: async (_, args) => {
      const { data } = args

      const response = await client.request(updateAction, {id: args.id, action: data})
      return response.updateAction
    },
    createNote: async (_, args) => {
      const { data } = args

      const response = await client.request(createNote, {note: data})
      return response.createNote
    },
    createChecklist: async (_, args, context) => {
      authenticate(context)

      const { data } = args
      data.user = { connect: context.user.id }

      const response = await client.request(createChecklist, {checklist: data})
      return response.createChecklist
    },
    createCompany: async (_, args, context) => {
      authenticate(context)

      const { data } = args

      const logo = JSON.parse(data.logo)
      const buf = new Buffer(logo.body.replace(/^data:image\/\w+;base64,/, ""),'base64')

      const params = {
        Bucket: 'talenth',
        Key: logo.name,
        Body: buf,
      }
      let uploadPromise = await s3.upload(params).promise()

      data.logo = uploadPromise.Location
      data.user = { connect: context.user.id }

      const response = await client.request(createCompany, {company: data})
      return response.createCompany
    },
    updateCompany: async (_, args, context) => {
      authenticate(context)

      const { data } = args

      if (data.logo && !data.logo.includes('https')) {
        const logo = JSON.parse(data.logo)
        const buf = new Buffer(logo.body.replace(/^data:image\/\w+;base64,/, ""),'base64')

        const params = {
          Bucket: 'talenth',
          Key: logo.name,
          Body: buf,
        }
        let uploadPromise = await s3.upload(params).promise()
        data.logo = uploadPromise.Location
      }

      const response = await client.request(updateCompany, {id: args.id, company: data})
      return response.updateCompany
    },    
  }
}

const server = new ApolloServer({
  typeDefs,
  resolvers,
  context: (req) => {
    const tokenWithBearer = req.event.headers.authorization || ''
    const user = getUser(tokenWithBearer.split(' ')[1])
    return { user }
  },
  formatError: (err) => {
    if (err.message.startsWith("Instance is not unique.: ")) {
      return new AuthenticationError('User already exists.')
    }
    return err
  }
})

exports.handler = server.createHandler()