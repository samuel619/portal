import gql from 'graphql-tag'

export const VALIDATE_TOKEN = gql`
  query ValidateToken {
    validateToken {
      name
      email
    }
  }
`

export const FIND_COMPANY = gql`
  query FindCompany {
    findCompany {
      _id
      name
      about
      website
      email
      logo
      address
      latitude
      longitude
      jobs {
        data {
          _id
          _ts
          title
          status
          description
          stages
          talents {
            data {
              _id
              name
              email
              title
              stage
            }
          }
        }
      }
    }
  }
`

export const UPDATE_COMPANY = gql`
  mutation UpdateCompany($id: ID!, $company: CompanyInput!) {
    updateCompany(id: $id data: $company) {
      _id
      name
      about
      website
      email
      logo
      address
      latitude
      longitude
    }
  }
`

export const CREATE_COMPANY = gql`
  mutation CreateACompany($company: CompanyInput!) {
    createCompany(data: $company) {
      _id
      name
      about
      website
      email
      logo
      address
      latitude
      longitude
    }
  }
`

export const ALL_JOBS = gql`
  query AllJobs {
    allJobs {
      data {
        _id
        _ts
        title
        status
        description
        stages
        company {
          about
          name
          logo
        }
        talents {
          data {
            _id
            name
            email
            title
            stage
          }
        }
      }
    }
  }
`

export const ALL_ACTIVE_JOBS_QUERY = gql`
  query AllActiveJobs {
    allActiveJobs {
      data {
        _id
        _ts
        title
        description
        company {
          name
          about
          logo
          address
          latitude
          longitude
        }
      }
    }
  }
`

export const FIND_JOB = gql`
  query FindJobByID($id: ID!) {
    findJobByID(id: $id) {
      status
      title
      description
      stages
      company {
        _id
        logo
        name
        email
        address
        latitude
        longitude
        about
        jobs {
          data {
            _id
            _ts
            title
          }
        }
      }
    }
  }
`

export const CREATE_JOB = gql`
  mutation CreateAJob($job: JobInput!) {
    createJob(data: $job) {
      _id
      _ts
      title
      description
      talents {
        data {
          _id
        }
      }
    }
  }
`

export const UPDATE_JOB = gql`
  mutation UpdateJob($id: ID!, $job: JobInput!) {
    updateJob(id: $id data: $job) {
      _id
      _ts
      title
      status
      description
      stages
      company {
        name
        about
        logo
        address
        latitude
        longitude
      }
      talents {
        data {
          _id
        }
      }
    }
  }
`

export const CREATE_APPLICATION = gql`
  mutation CreateAnApplication($application: ApplicationInput!) {
    createApplication(data: $application) {
      _id
    }
  }
`

export const ALL_HIRED_TALENTS = gql`
  query AllHiredTalents {
    allHiredTalents {
      data {
        _id
        name
        email
        stage
        job {
          _id
          title
        }
        checklists {
          data {
            _id
            _ts
            name
            type
            steps {
              data {
                _id
                name
                content
                actions {
                  data {
                    _id
                    name
                    content
                    assignee
                    completed
                    data
                  }
                }
              }
            }
          }
        }
      }
    }
  }
`

export const ADD_TALENT = gql`
  mutation AddATalent($talent: TalentInput!) {
    addTalent(data: $talent) {
      _id
      title
      email
      name
      stage
    }
  }
`

export const CREATE_NOTE = gql`
  mutation CreateANote($note: NoteInput!) {
    createNote(data: $note) {
      _id
      _ts
      feedback
      provider
      content
      owner
    }
  }
`

export const FIND_TALENT = gql`
  query FindTalentByID($id: ID!) {
    findTalentByID(id: $id) {
      name
      email
      title
      resume
      stage
      state
      notes {
        data {
          _id
          _ts
          feedback
          provider
          content
          owner
        }
      }
      job {
        _id
        title
        stages
      }
    }
  }
`

export const UPDATE_TALENT = gql`
  mutation UpdateTalent($id: ID!, $talent: TalentInput!) {
    updateTalent(id: $id data: $talent) {
      _id
      name
      email
      title
      resume
      stage
      job {
        _id
        stages
      }
      checklists {
        data {
          _id
          _ts
          name
          type
          steps {
            data {
              _id
              name
              content
              actions {
                data {
                  _id
                  name
                  content
                  assignee
                  data
                }
              }
            }
          }
        }
      }
    }
  }
`

export const SIGN_IN_USER = gql`
  mutation SignInUser(
    $email: String!,
    $password: String!
  ) {
    signIn(data: {
      email: $email
      password: $password
    }) {
      token
      user {
        _id
        name
        email
      }
    }
  }
`

export const SIGN_UP_USER = gql`
  mutation SignUpUser(
    $name: String!,
    $email: String!,
    $password: String!
  ) {
    signUp(data: {
      name: $name
      email: $email
      password: $password
    }) {
      token
      user {
        _id
        name
        email
      }
    }
  }
`

export const GET_USER = gql`
  query getUser {
    getUser {
      token
      user {
        email
      }
    }
  }
`

export const UPDATE_STEP = gql`
  mutation UpdateAStep($id: ID!, $step: StepInput!) {
    updateStep(id: $id data: $step) {
      _id
      name
      actions {
        data {
          _id
          item
          completed
        }
      }
    }
  }
`

export const FIND_ACTION = gql`
  query FindActionByID($id: ID!) {
    findActionByID(id: $id) {
      name
      assignee
      content
    }
  }
`

export const UPDATE_ACTION = gql`
  mutation UpdateAnAction($id: ID!, $action: ActionInput!) {
    updateAction(id: $id data: $action) {
      _id
      completed
    }
  }
`

export const ALL_CHECKLIST_TEMPLATES = gql`
  query AllChecklistTemplates {
    allChecklistTemplates {
      data {
        _id
        _ts
        name
        type
        steps {
          data {
            _id
            name
            content
            actions {
              data {
                _id
                name
                content
                assignee
                data
              }
            }
          }
        }
      }
    }
  }
`

export const ALL_CHECKLISTS = gql`
  query AllChecklists {
    allChecklists {
      data {
        _id
        _ts
        name
        type
        steps {
          data {
            _id
            name
            content
            actions {
              data {
                _id
                name
                content
                assignee
                data
              }
            }
          }
        }
        talent {
          _id
        }
        user {
          _id
        }
      }
    }
  }
`

export const CREATE_CHECKLIST = gql`
  mutation CreateAChecklist($checklist: ChecklistInput!) {
    createChecklist(data: $checklist) {
      _id
    }
  }
`