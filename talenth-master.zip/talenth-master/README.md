<p align="center">
  <img src="https://user-images.githubusercontent.com/9268746/63213417-35108c00-c11d-11e9-8296-18b338dcc6df.png" height="60" /><br/><br/>
  <span><b>Talenth</b>: <span>Open source HR platform</span><br/>
</p>

<p align="center">
  <a href="https://app.netlify.com/sites/talenth-prod/deploys"><img src="https://api.netlify.com/api/v1/badges/6a911a11-1a42-4fa5-8c68-617943dde091/deploy-status"></a>
  <a href="https://circleci.com/gh/spacehelmet/talenth/tree/master"><img src="https://circleci.com/gh/spacehelmet/talenth/tree/master.svg?style=svg"></a>  
</p>

___

## Why

Talenth is a web app to help HR teams with **recruitment**, **onboarding**, **offboarding** and **analytics**. Post jobs, track applicants, onboard new-hires and never miss anything important.

## Features

- [x] **Job board with a map support**: Filter, browse and apply to available jobs in a certain area,
- [x] **Hiring pipeline**: Post jobs, create a hiring pipeline and manage applicants,
- [x] **Workflows**: Create custom onboarding and offboarding workflows for each job,
- [x] **Onboarding and Offboarding**: Create a list of tasks to do, assign to team members and track the progress,
- [x] **Slack link unfurling and submit feedback**: View the candidate details in Slack and submit interview feedback directly from Slack

## Modules

### Recruiting

Create job postings, manage applicant pipeline and schedule interviews.

![board](https://user-images.githubusercontent.com/9268746/67415828-c34e3600-f5d6-11e9-8d96-899a5988a2bc.png)
![pipeline](https://user-images.githubusercontent.com/9268746/67415909-eaa50300-f5d6-11e9-9589-47435b347522.png)

### Onboarding

Create custom workflows and recipes for each job and/or candidate.

![onboarding](https://user-images.githubusercontent.com/9268746/67416037-25a73680-f5d7-11e9-9df0-29b75ab307c0.png)

## Integrations

The platform is integrated with following services:
- [FaunaDB](https://fauna.com)
- [SendGrid](https://sendgrid.com)
- [Slack](https://slack.com)
- [AWS S3](https://aws.amazon.com/s3)

## Usage

Firstly, create a `.env` in the root directory with following content
```
FAUNADB_API=<HOST URL FOR YOUR GRAPHQL API, FOR EXAMPLE: https://graphql.fauna.com/graphql>
FAUNADB_TOKEN=<API AUTH TOKEN>
REACT_APP_GMAPS_TOKEN=<GMAPS TOKEN WITH PLACES MODULE ENABLED>
REACT_APP_GRAPHQL_LAMBDA=<LAMBDA FUNCTION PATH, FOR EXAMPLE: /.netlify/functions/fauna>
SECRET_TOKEN = <STRING FOR JWT TOKEN GENERATION>
SENDGRID_API_KEY
S3_ACCESS_KEY_ID
S3_SECRET_ACCESS_KEY_ID
SLACK_CLIENT_TOKEN
```

Make sure `netlify-lambda` and `run-p` are available globally. Then just do

```
yarn install
yarn start
```

## License

[MIT](LICENSE)
